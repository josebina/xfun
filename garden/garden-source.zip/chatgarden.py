from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
W=1280
im=Image.new('RGB',(W,6800),'#f5f5ef');d=ImageDraw.Draw(im)
def font(n,b=False):return ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-'+('Bold' if b else 'Regular')+'.ttc',n,index=2)
def txt(x,y,t,n=30,b=False,fill='#24362e'):d.text((x,y),t,font=font(n,b),fill=fill,anchor='lt')
def flow(t,width=1088):
 f=font(29);out=[]
 for p in t.split('\n'):
  line=''
  for c in p:
   if f.getlength(line+c)>width:out.append(line);line=''
   line+=c
  out.append(line)
 return out
y=170
def block(label,t,photo=False):
 global y
 a=flow(t); h=105+len(a)*46+(832 if photo else 0)
 d.rounded_rectangle((54,y,1226,y+h),radius=22,fill='#e6eee3' if label=='用户' else '#ffffff',outline='#dce4d9',width=2)
 txt(91,y+28,label,23,True,'#4f705b')
 yy=y+78
 for l in a:
  if l:txt(91,yy,l.replace('**',''),29)
  yy+=46
 if photo:
  p=Image.open('/workspace/scratch/garden/reference.jpg').convert('RGB').resize((1098,824),Image.Resampling.LANCZOS)
  im.paste(p,(91,yy+7))
 y+=h+23
txt(54,42,'教学楼庭院三维重建',50,True)
txt(57,113,'会话记录',24,False,'#5d7665')
block('用户','这是在一栋6层高的教学楼的屋顶拍摄的俯视图，需要为图中的花园建立三维模型，要求在保留原貌特征的情况下越精细越好，请先充分辨识图中的景观元素，根据图中的人物推算它们的大概尺寸。为了得到更好的效果，你可以先进行规划然后分步实现，生成过程中人工不再介入。如果你能检索出这是哪里，可以尝试从网络获取其它视角的图片或文字描述。',True)
updates=[
'我会先用照片里远近不同的人物估算尺度，再按铺装边界、草坡、廊架和树木的位置分层建模。成品会包含可旋转查看的三维模型、接近原拍摄角度的预览，以及尺寸估算依据。',
'照片里的草坡有三层清楚可辨的边界：黄绿色地被、放射状深灰片石，以及上方草坪。按四处站立人物取约 1.70 米身高，并用两侧楼体校正透视，坡脚初估约宽 27 米、沿拍摄方向长 30 米。后方三开间蓝灰瓦亭、两翼弧廊和廊前水面也能辨认；草坪上的散杆、格架和人物会单独分层，方便切换。',
'我会用 Blender 制作有真实几何和材质的模型，并按云端工作区技能的交付方式打包文件，让你能下载、旋转查看和继续编辑。',
'主体模型已搭好。片石、瓦脊、廊架格栅、栏杆、长椅和水池压顶都做成了立体构件。现在我会把模型投回原拍摄角度，核对草坡轮廓、亭顶高度和两侧树冠，再用轴测视图检查照片里容易被遮住的部分。',
'原机位回投已经完成，坡脚、草坪上缘、亭顶和两翼廊架都已与照片逐项对照。离线查看器也已验证，可以旋转模型、切换图层，并把原照叠在模型上检查吻合程度。尺寸说明会注明哪些边界能直接从照片辨认，哪些高度和背面形状依赖推算。',
'亭廊近景检查时发现，广场与弧形水渠的交接处有一道多余细缝，已经修正。Blender 工程已重新打开核验，24 张材质贴图均已内嵌；我正在用修正后的模型更新最终对照图。']
for t in updates:block('助手 · 进度更新',t)
block('助手 · 最终回复','''庭院三维模型已完成。下载后用浏览器打开，便可旋转查看、切换轴测和亭廊近景，也可叠加原照检查轮廓。人物、散杆和临时格架可以单独隐藏。[打开离线三维查看器]

模型与图纸
• 可编辑的米制 Blender 工程，24 张材质贴图已内嵌。[下载 Blender 源文件]
• 可导入其他三维软件的通用模型。[下载 GLB 模型]
• 静态预览。[原照片与模型同机位对照] · [庭院轴测总览]
• 五页图册，包含景观辨识标注、人物定标过程、带比例尺的总平面和草坡剖面。[下载景观辨识与尺寸说明]

主要尺寸估算
取四处站立人物作参照，近处人物在原图中约高 38 像素，远处约高 25–27 像素。按身高 1.70 米、结合两侧楼檐和立柱校正透视，推得拍摄点距庭院地面约 25 米。

景观元素　／　估算尺寸
• 中央草坡　坡脚约 26.6 × 29.6 米，上层草坪约 24 × 24 米，上缘高出环道约 2 米
• 两侧环道　草坡中段净宽约 3–4 米
• 三开间瓦亭　屋面约 15.6 × 7.0 米，檐高约 3.5 米，最高屋脊约 5.6 米
• 双翼弧廊　单翼沿中线约长 17 米、宽 3.5 米，两翼最外端相距约 41 米
• 左前矩形水池　池缘外包约 4.0 × 3.5 米

模型保留了草坡上伸入草坪的扇形浅石、放射状深灰片石、坡脚黄绿色地被，以及两侧不对称的方格花园。坡背、亭后和楼体背面按可见构造补全，这些部位的不确定性较高。具体校址未能从照片中核实。''')
txt(56,y+3,'会话内的文件链接以文字保留。',22,False,'#5d7665')
p=Path('/workspace/庭院三维重建-会话长图.png')
im.crop((0,0,W,y+58)).save(p,optimize=True)
with Image.open(p) as out: print(out.size);out.verify()
