from common import *
def activity():
    people=Mesh();props=Mesh();chips=Mesh()
    palette=['#292c2c','#52666b','#84bcc1','#525b61','#4e737d','#b45b2d','#dedccf','#c0c6b8','#354e67','#674c50','#747d79','#342e3a']
    cloth=[mat('H%02d  服装'%i,c,.92) for i,c in enumerate(palette)]
    skin=[mat('H2%d  人物肤色'%i,c,.85) for i,c in enumerate(['#b39279','#c4a38c','#a68a76'])]
    hair=[mat('H3%d  头发'%i,c,.87) for i,c in enumerate(['#30302d','#3e3731','#28282a'])]
    bamboo=[mat('T5%d  竹木状杆件'%i,c,.8) for i,c in enumerate(['#c4ae7d','#d3bd90','#aa946b','#ceb27d','#e2cc9e'])]
    chipmat=[mat('T6%d  浅色碎料'%i,c,.92) for i,c in enumerate(['#cdbb96','#dfccab','#e2d0aa','#c0aa83','#d8c196'])]
    mint=mat('T07  浅绿色活动凳','#a3b773',.59);bag=mat('H40  深色随身物','#333b42',.75)
    def land(u,v):
        z=2.06
        for _ in range(4):
            x,y=xy(u,v,z);z=turfz(x,y)
        return x,y,z
    def point(u,v,grasssite):
        return land(u,v) if grasssite else (*xy(u,v),.012)
    def person(u,v,zz,angle,height,shirt,pants,pose='stand',site='ground',variant=0):
        if site=='lawn':xx,yy,zbase=land(u,v)
        else:xx,yy=xy(u,v,zz);zbase=zz
        r=random.Random(u*123+v);cs=cos(angle);sn=sin(angle);scale=height/1.70
        def P(q):
            x,y,z=q;return V((xx+scale*(x*cs-y*sn),yy+scale*(x*sn+y*cs),zbase+scale*z))
        standing=(pose not in ['sit','crouch'])
        hip=.89 if standing else (.54 if pose=='sit' else .42)
        chest=hip+.44
        lean=0 if standing else (.105 if pose=='sit' else .29)
        def body(q,rad,m):pipe(people,[P(pt) for pt in q],[rv*scale for rv in rad],m,10)
        def egg(p,s,m):oval(people,P(p),tuple(q*scale for q in s),m,11,7,angle)
        sk=skin[variant%3];hr=hair[variant%3];shoe=cloth[1 if variant%3==1 else 0]
        for sd in [-1,1]:
            ky=.028+.057*sd if standing else (.38 if pose=='sit' else .24)
            knee=(sd*(.124 if standing else .154),ky,.48 if standing else (.49 if pose=='sit' else .52))
            foot=(sd*(.14 if standing else .163),sd*.101 if standing else (.42 if pose=='sit' else -.025),.09)
            body([(sd*.102,0,hip),knee,foot],[.096,.074,.051],cloth[pants])
            egg((foot[0],foot[1]+.052,.077),(.068,.136,.058),shoe)
        torso=[]
        for z,w,d,cy in [(hip-.12,.158,.122,0),(hip+.04,.175,.118,lean*.20),(hip+.27,.202,.117,lean*.53),(chest,.219,.125,lean),(chest+.051,.143,.110,lean)]:
            torso.append(people.points([P((w*cos(i*pi/7),cy+d*sin(i*pi/7),z)) for i in range(14)]))
        people.face(torso[0][::-1],cloth[shirt]);people.face(torso[-1],cloth[shirt])
        for lo,hi in zip(torso,torso[1:]):
            for j in range(14):k=(j+1)%14;people.face([lo[j],lo[k],hi[k],hi[j]],cloth[shirt],True)
        body([(0,lean,chest+.024),(0,lean+.015,chest+.154)],[.072,.059],sk)
        hx=lean+.028
        egg((0,hx,chest+.246),(.099,.106,.134),sk)
        egg((-.003,hx-.013,chest+.299),(.100,.105,.098),hr)
        egg((0,hx+.097,chest+.234),(.025,.028,.033),sk)
        if variant%5==1:egg((0,hx-.089,chest+.236),(.082,.059,.108),hr)
        for sd in [-1,1]:
            shoulder=(sd*.194,lean,chest-.021)
            if pose=='point' and sd==-1:
                el=(sd*.298,lean+.156,chest+.055);hand=(sd*.335,lean+.371,chest+.182)
            elif pose in ['sit','crouch']:
                el=(sd*.247,lean+.09,chest-.206);hand=(sd*.163,lean+.267,chest-.317)
            elif pose=='fold' or (variant%4==1 and sd==1):
                el=(sd*.244,lean+.02,chest-.245);hand=(sd*.092,lean+.15,chest-.16)
            else:
                el=(sd*.234,lean+.01,chest-.235);hand=(sd*.228,lean+.091,chest-.447)
            body([shoulder,el,hand],[.073,.058,.038],cloth[shirt]);egg(hand,(.044,.043,.062),sk)
    # Coordinates refer to visible ground-contact points, or to the vertical support below a seated person.
    for u,v,ang,h,s,p,pose,sv,n in [(992,837,2.10,1.70,0,0,'stand',0,0),(1005,868,2.98,1.66,6,0,'sit',0,1),(356,622,3.12,1.65,11,0,'fold',0,1),(114,687,-1.01,1.65,8,3,'crouch',.11,4),(798,564,.35,1.68,4,3,'stand',0,6),(806,554,2.1,1.73,0,0,'point',0,0),(813,565,2.56,1.63,0,0,'stand',0,1),(844,555,-1.5,1.7,0,3,'point',0,2),(840,581,1.02,1.68,6,0,'stand',0,6),(869,561,-2.,1.72,5,0,'stand',0,4),(641,447,.1,1.60,0,0,'stand',.34,2),(669,448,-1.3,1.7,0,3,'stand',.34,3),(642,457,1.6,1.66,0,0,'crouch',.3,4),(660,459,1.1,1.67,9,0,'crouch',.3,1)]:
        person(u,v,sv,ang,h,s,p,pose,variant=n)
    for i,(u,v,ang,s,p,pose) in enumerate([(628,605,-.1,7,10,'stand'),(650,592,2.5,0,0,'stand'),(671,594,-1.9,4,0,'stand'),(655,608,1.9,2,1,'crouch')]):
        person(u,v,0,ang,1.66+.025*i,s,p,pose,'lawn',i+2)
    people.build('Figures | 人物尺度与现场姿态 · 可隐藏','activity')
    outline=[(587,563),(593,558),(602,557),(610,555),(624,556),(635,553),(648,554),(657,553),(666,555),(680,553),(690,555),(702,555),(704,561),(709,569),(701,572),(693,572),(686,568),(674,569),(667,573),(655,572),(646,573),(637,572),(629,574),(617,575),(610,572),(599,573),(591,571)]
    # A thin uneven mat of light fragments with independently raised pieces.
    pts=[land(u,v) for u,v in outline];middle=tuple(np.mean(np.array(pts),axis=0))
    for i,p in enumerate(pts):
        q=pts[(i+1)%len(pts)];chips.poly([(middle[0],middle[1],turfz(*middle[:2])+.027),(p[0],p[1],p[2]+.031),(q[0],q[1],q[2]+.031)],chipmat[1])
    def inside(x,y):
        hit=False
        for i,(a,b,_) in enumerate(pts):
            c,d,_=pts[(i+1)%len(pts)]
            if (b>y)!=(d>y) and x<(c-a)*(y-b)/(d-b)+a:hit=not hit
        return hit
    arr=np.array(pts)
    for i in range(1750):
        x=rng.uniform(arr[:,0].min()-.23,arr[:,0].max()+.23);y=rng.uniform(arr[:,1].min()-.22,arr[:,1].max()+.22)
        if not inside(x,y) and rng.random()>.11:continue
        a=rng.uniform(0,2*pi);l=rng.uniform(.034,.21);z=turfz(x,y)+.034
        stonepiece(chips,(x,y,z),(x+cos(a)*l,y+sin(a)*l,z+.019),rng.uniform(.03,.112),.02,rng.choice(chipmat))
    chips.build('Pale fragments | 草坪后缘浅色碎料 · 可隐藏','activity')
    def pole(a,b,gs=True,r=.019):
        p=point(*a,gs);q=point(*b,gs)
        rod(props,(p[0],p[1],p[2]+.070),(q[0],q[1],q[2]+.082),r,rng.choice(bamboo),6)
    for a,b in [((477,649),(509,629)),((487,632),(511,650)),((521,642),(508,620)),((537,649),(532,633)),((553,653),(574,638)),((554,642),(591,621)),((574,662),(598,628)),((584,657),(587,630)),((515,633),(562,637)),((535,634),(556,635)),((549,651),(550,635)),((596,621),(653,610)),((613,615),(635,609)),((601,630),(638,617)),((590,620),(633,613)),((607,617),(630,606)),((573,638),(596,628)),((619,607),(630,593)),((681,614),(695,598)),((683,610),(711,585)),((672,592),(703,591))]:
        pole(a,b,r=rng.uniform(.016,.034))
    for j in range(44):
        u=rng.uniform(536,592) if j<29 else rng.uniform(477,531);v=rng.uniform(635,656);ang=rng.uniform(-.34,1.23);ll=rng.uniform(7.5,25.)
        pole((u,v),(u+cos(ang)*ll,v-sin(ang)*ll),r=rng.uniform(.018,.034))
    for j in range(9):pole((704+4.3*j,588),(699+4.4*j,601),r=.019)
    for j in range(6):pole((702-j*.5,588+j*2.6),(743-j*.5,589+j*2.6),r=.018)
    for j in range(8):
        u=rng.uniform(543,564);v=rng.uniform(639,655);x,y,z=land(u,v)
        box(props,x,y,z+.063,rng.uniform(.078,.174),rng.uniform(.36,.92),.032,rng.choice(chipmat),rng.uniform(-1.5,1.5))
    for gs,px,py,h in [(True,650,589,1.58),(False,813,571,1.36),(False,847,565,1.71)]:
        p=point(px,py,gs)
        for a in [.14,2.20,4.47]:
            x=p[0]+.82*cos(a);y=p[1]+.82*sin(a);z=turfz(x,y) if gs else .04
            rod(props,(x,y,z),(p[0],p[1],p[2]+h),.022,bamboo[0],6)
    for j in range(6):pole((853+j*.85,579),(878+j*.7,559),False,.019)
    for u,v,gs in [(618,590,True),(852,567,False)]:
        x,y,z=point(u,v,gs);slab(props,x,y,z+.37,.37,.38,.067,mint,.025)
        for i in [-1,1]:
            for j in [-1,1]:beam(props,(x+i*.18,y+j*.18,z+.014),(x+i*.133,y+j*.133,z+.386),.043,.046,mint)
    for u,v in [(724,617),(628,596)]:
        x,y,z=land(u,v);slab(props,x,y,z+.052,.38,.30,.13,bag);slab(props,x,y,z+.177,.35,.26,.034,cloth[2],.009)
    for u,v in [(278,722),(914,565),(1018,850)]:
        x,y=xy(u,v,.48);oval(props,(x,y,.56),(.21,.16,.110),bag)
    props.build('Workshop | 散落杆件、格架、活动凳及随身物 · 可隐藏','activity')
