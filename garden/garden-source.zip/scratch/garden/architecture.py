from common import *
def architecture():
    building=Mesh();frames=Mesh();roof=Mesh();services=Mesh()
    warm=mat('F01  西楼水刷石外墙','#aaa394',.90,'wall.jpg',3.35)
    cool=mat('F02  东楼横缝浅色面砖','#cdcfca',.82,'masonry.jpg',2.4)
    pil=mat('F03  淡灰混凝土柱','#bab8ab',.87)
    red=mat('F04  深褐红贴面','#82493f',.83)
    jamb=mat('F05  窗洞阴影','#424849',.82)
    alum=mat('F06  铝合金窗料','#a7aaa2',.5,metal=.44)
    blue=mat('F07  钴蓝压型板','#6e98c5',.55,metal=.23)
    blue2=mat('F08  屋脊钢板','#849fc0',.56,metal=.28)
    grille=mat('F09  风口与窗格','#687073',.59,metal=.32)
    winw=mat('F10  西楼玻璃','#556269',.39,'window_w.jpg',2.55,metal=.06)
    wine=mat('F11  东楼玻璃','#637577',.42,'window_e.jpg',2.42,metal=.08)
    panes=[mat('F2%d  玻璃与窗帘'%j,col,.44,metal=.09) for j,col in enumerate(['#5b6b6c','#67787a','#738381','#899491','#536368','#7b8a88','#667775'])]
    ivory=mat('F12  百叶与空调机箱','#c4c5b8',.65,metal=.16)
    dust=mat('F13  泛碱与雨渍','#a5a297',.91)
    expwall=mat('F14  粗糙墙面','#92948a',.9)
    def wallwindow(x,y,z,width,height,side,west=False,kind=0):
        # x always sits at the exterior wall face. Positive side projects outward into the court.
        def layer(b,offset,sill,w,h,depth,m,dy=0):
            box(b,x+side*offset,y+dy,sill,depth,w,h,m)
        layer(building,.025,z-.08,width+.15,height+.15,.065,jamb)
        layer(frames,.069,z,width,height,.040,winw if west else wine)
        n=(3 if width>2.7 else 2) if not west else 3
        trans=.64 if not west else .58
        for j in range(n):
            w=width/n
            if rng.random()<(.73 if not west else .27):
                layer(frames,.092,z+.04,w-.065,height*trans-.061,.019,rng.choice(panes if not west else panes[:2]),-width/2+w*(j+.5))
            for yy in ([-width/2] if j==0 else [])+[(-width/2+(j+1)*w)]:
                layer(frames,.111,z,.04 if west else .065,height,.07,alum,yy)
        for zz in [z,z+height*trans,z+height]:
            layer(frames,.111,zz,width+.03,.055,.071,alum)
        if west and height>2:
            layer(frames,.115,z+height*.31,width,.029,.05,grille)
            for j in range(1,7):layer(frames,.120,z,.016,height,.020,grille,-width/2+j*width/7)
        layer(frames,.132,z-.09,width+.17,.075,.21,pil)
    # Long blue-roofed teaching/workshop block, eaves measured at about 10 m.
    wx=-32.76;w=14.;lo=-17.1;hi=78.8
    box(building,wx-w/2,(lo+hi)/2,-.15,w,hi-lo,10.37,warm)
    for side in [1,-1]:
        xf=wx if side==1 else wx-w
        for j,yy in enumerate(np.arange(-15.05,hi-1,4.15)):
            box(frames,xf+side*.089,yy-2.03,.09,.23,.30,8.60,pil)
            if side==1 and (j in [8,18]):
                d=mat('F15  卷闸与门扇','#aba995',.67)
                for dd in [-.81,.81]:box(frames,xf+side*.09,yy+dd,.055,.19,1.58,3.68,d)
                for z in np.arange(.32,3.7,.16):box(frames,xf+.197,yy,z,.018,3.18,.015,dust)
                slab(services,xf+.68,yy,3.90,1.62,4.02,.14,metal,.024)
                for delta in [-1.54,1.54]:beam(services,(xf+.09,yy+delta,3.36),(xf+1.12,yy+delta,3.87),.055,.065,metal)
            else:wallwindow(xf,yy,.48,2.83,3.57,side,True)
            wallwindow(xf,yy,5.53,2.78,1.47,side,True)
            if side==1:
                for k in range(3):
                    xz=rng.uniform(4.62,5.13)
                    box(services,xf+.007,yy+rng.uniform(-1.47,1.47),xz,.019,rng.uniform(.035,.12),rng.uniform(.12,.31),dust)
                if j%3==1:
                    x=xf+.40;by=yy-1.30
                    slab(services,x,by,.12,.59,1.05,.55,ivory,.034)
                    oval(services,(x+.30,by,.40),(.018,.21,.21),grille,14,7)
                    for off in np.arange(-.17,.2,.054):box(services,x+.325,by,.4+off,.026,.34,.013,alum)
                    pipe(services,[(x-.1,by+.37,.50),(xf+.12,by+.70,.70),(xf+.10,by+.7,2.05)],.041,ivory,7)
        rod(services,(xf+side*.1,lo,9.99),(xf+side*.1,hi,9.99),.082,steel)
    # Corrugated geometry runs down each roof slope.
    for sd in [-1,1]:
        ridgeX=wx-w/2;edgeX=ridgeX+sd*(w/2+.19)
        rings=[]
        for j,yy in enumerate(np.linspace(lo-.25,hi+.25,int((hi-lo)/.106))):
            dz=.033 if j%2 else -.016
            rings.append(roof.points([(ridgeX,yy,12.18+dz),(edgeX,yy,10.19+dz)]))
        for j in range(len(rings)-1):
            a,c=rings[j],rings[j+1];ids=[a[0],a[1],c[1],c[0]];roof.face(ids if sd==1 else ids[::-1],blue)
        for yy in [lo-.25,hi+.25]:beam(roof,(ridgeX,yy,12.19),(edgeX,yy,10.2),.095,.09,blue2)
    rod(roof,(wx-w/2,lo-.26,12.23),(wx-w/2,hi+.26,12.23),.097,blue2,10)
    for yy in [lo,hi]:building.poly([(wx,yy,10.2),(wx-w/2,yy,12.16),(wx-w,yy,10.2)],warm)
    for yy in [1.5,22.5,46.7,66.5]:
        pipe(services,[(wx+.20,yy,.17),(wx+.20,yy,9.55),(wx+.29,yy,10.01)],.069,ivory,8)
    # Eastern block: coloured band above the ground floor and an articulated near corner.
    for start,end,xf,maxz in [(-19.3,3.45,29.72,21.05),(3.45,50.65,30.68,20.47)]:
        dd=13.72
        box(building,xf+dd/2,(start+end)/2,-.14,dd,end-start,maxz+.14,cool)
        for face in [0,1]:
            sx=xf if face==0 else xf+dd;sg=-1 if face==0 else 1
            for yy in np.arange(start+1.47,end-.45,3.03):
                for k,zz in enumerate([.92,4.98,8.80,12.66,16.48]):
                    width=min(2.67,max(.45,2*(end-yy-.10)))
                    wallwindow(sx,yy,zz,width,2.19,sg,False,k)
                if face==0:
                    box(frames,sx-.13,yy,3.25,.28,3.02,1.08,red)
                    box(frames,sx-.10,yy-1.48,.02,.24,.20,3.31,red)
                if yy+1.25<end:
                    box(frames,sx+sg*.06,yy,19.54,.14,2.46,.30,grille)
                    for z in [19.60,19.69,19.78]:box(frames,sx+sg*.14,yy,z,.045,2.48,.028,alum)
            box(frames,sx+sg*.12,(start+end)/2,20.04,.26,end-start,.22,pil)
        # Secondary end walls and roof parapets are simple inferred closures.
        for yy in [start,end]:
            for xx in np.arange(xf+1.65,xf+dd-.5,3.14):
                for z in [.91,4.98,8.8,12.66,16.48]:
                    faceY=yy-.044 if yy==start else yy+.044
                    box(frames,xx,faceY,z,2.28,.085,2.19,rng.choice(panes))
                    box(frames,xx,faceY+(-.03 if yy==start else .03),z, .066,.095,2.19,alum)
        for x in [xf,xf+dd]:box(roof,x,(start+end)/2,maxz-.04,.23,end-start,.49,cool)
        box(roof,xf+dd/2,(start+end)/2,maxz,dd-.3,end-start-.2,.15,expwall)
    # Recessed roof gallery visible above the right facade.
    box(building,37.90,12.0,20.67,6.18,55.42,3.20,cool)
    for yy in np.arange(-15.0,39.5,3.21):
        box(frames,33.08,yy,20.64,.34,.39,3.10,pil)
        box(frames,34.68,yy,21.02,.105,1.36,2.02,grille)
    box(frames,33.08,12.35,23.52,.37,55.52,.69,red)
    box(roof,37.10,12.3,24.17,8.59,55.85,.18,cool)
    # The rear teaching range is partially visible through the trees.
    box(building,-1.1,63.2,-.18,66,11.7,15.18,cool)
    for xx in np.arange(-32.35,31.7,3.2):
        for z in [1.04,5.0,8.98,12.43]:
            box(frames,xx,57.30,z,2.47,.12,1.90,jamb)
            for dx in [-.80,0,.80]:
                box(frames,xx+dx,57.223,z+.06,.74,.05,1.77,rng.choice(panes))
        box(frames,xx-1.4,57.20,.10,.24,.37,14.73,pil)
    box(roof,-1.05,63.15,15.01,66.4,12.3,.30,expwall)
    for xx in [-26,-7.5,13.1]:
        box(roof,xx,64.2,15.15,5.4,5.1,.66,expwall)
    for yy in [50.93]:
        box(services,-2.10,yy,.02,60.7,.24,1.14,expwall);box(services,-2.10,yy,1.16,60.9,.34,.08,pil)
    building.build('Architecture | 教学楼体量与可见立面','buildings')
    frames.build('Fenestration | 窗框、横梃、瓷砖面带与柱网','buildings')
    roof.build('Roofs | 西楼蓝色压型板、女儿墙与屋顶柱廊','buildings')
    services.build('Services | 空调、雨管、门篷及背景围墙','buildings')
def rear_garden():
    b=Mesh();f=Mesh();cream=mat('T09  米白伞布','#e1d9bf',.92)
    # Paving and small pools behind the pergola, seen in the gaps in the trees.
    rect(b,-32.7,36.3,30.6,51.5,.02,grav)
    for x,y,w,d in [(-23.2,44.1,7.8,3.36),(-17.0,47.2,3.15,2.45)]:
        box(b,x,y,.022,w,d,.14,darkstone);rect(b,x-w/2+.12,y-d/2+.12,x+w/2-.12,y+d/2-.12,.17,wet)
        for sd in [-1,1]:
            box(b,x+sd*w/2,y,.13,.12,d+.13,.084,lightstone)
            box(b,x,y+sd*d/2,.13,w+.09,.12,.084,lightstone)
    for u,v in [(396,426),(439,423)]:
        x,y=xy(u,v,2.67)
        rod(f,(x,y,.04),(x,y,2.68),.030,steel,8)
        for j in range(8):
            t=2*pi*j/8;u0=2*pi*(j+1)/8
            a=(x+1.48*cos(t),y+1.48*sin(t),2.10);q=(x+1.48*cos(u0),y+1.48*sin(u0),2.10)
            f.poly([a,q,(x,y,2.67)],cream);rod(f,a,(x,y,2.65),.014,ivory if 'ivory' in globals() else lightstone,6)
        pipe(f,[(x,y,.76),(x,y,.81)],.56,lightstone,20)
    b.build('Rear court | 后庭铺地与水景','site');f.build('Parasols | 廊后两把浅色遮阳伞','furniture')
def photographic_fronts():
    left=mat('F31  西楼实景正射立面','#b6b1a5',.83,'facade_west.jpg')
    right=mat('F32  东楼实景正射立面','#bec4c1',.77,'facade_east.jpg')
    for nm in [left,right]:
        mt=mats[nm];bs=mt.node_tree.nodes.get('Principled BSDF')
        tex=next(q for q in mt.node_tree.nodes if q.type=='TEX_IMAGE')
        mt.node_tree.links.new(tex.outputs['Color'],bs.inputs['Emission Color'])
        bs.inputs['Emission Strength'].default_value=.15
    for ob in collections['buildings'].objects:
        if not ob.name.startswith(('Architecture','Fenestration')):continue
        me=ob.data;me.materials.append(mats[left]);me.materials.append(mats[right]);idx=len(me.materials)-2
        uv=me.uv_layers.active.data
        for face in me.polygons:
            x,y,z=face.center
            if -33.15<x<-32.35 and face.normal.x>.77 and z<10.34:
                lo,hi,hh=-17.1,78.8,10.37;face.material_index=idx
            elif 29.25<x<30.86 and face.normal.x<-.77 and -.1<z<20.6:
                lo,hi,hh=-19.3,50.65,20.8;face.material_index=idx+1
            else:continue
            for k in face.loop_indices:
                p=me.vertices[me.loops[k].vertex_index].co
                uv[k].uv=((p.y-lo)/(hi-lo),max(0,min(1,p.z/hh)))
    # Beyond the west eave, the photograph only establishes a backdrop of foliage.
    b=Mesh();box(b,-55.6,45.0,-.57,20.2,75.8,.49,soil)
    b.build('Outer landscape | 西楼外简化地面','buildings')
