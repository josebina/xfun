import json, math, random
from pathlib import Path
import numpy as np
from scipy import ndimage as nd
from PIL import Image, ImageDraw, ImageFilter
from calib import H, OX, OY, F, CX, CY, C, S

root=Path(__file__).parent
dst=root/'textures'
rng=np.random.default_rng(9073)
pr=random.Random(9168)
ref=np.array(Image.open(root/'reference.jpg').convert('RGB'))
def field(n,scale):
    a=nd.gaussian_filter(rng.normal(size=(n,n)),scale,mode='wrap')
    return a/(np.std(a)+1e-8)
def save(name,a):
    Image.fromarray(np.uint8(np.clip(a,0,255))).save(dst/(name+'.jpg'),quality=94,subsampling=0)
def tile(name,base,coarse,fine,texture=None):
    n=512
    v=field(n,42)*coarse+field(n,8)*coarse*.5+field(n,1.6)*fine*.48+field(n,.3)*fine
    out=np.array(base)[None,None,:]+v[:,:,None]
    if texture=='granite':
        chips=nd.maximum_filter(rng.random((n,n))>.985,2)
        out[chips]-=rng.uniform(15,57,(chips.sum(),1))
    elif texture=='soil':
        out[:,:,0]+=field(n,6)*4
        o=Image.fromarray(np.uint8(np.clip(out,0,255)));d=ImageDraw.Draw(o)
        for i in range(1100):
            x,y=rng.integers(0,512,2);dx,dy=rng.normal(0,2.3,2)
            d.line((x,y,x+dx,y+dy),fill=pr.choice(['#69513b','#9a8365','#4f4734','#997b4e']),width=pr.choice([1,1,2]))
        out=np.array(o)
    elif texture=='wood':
        grain=nd.gaussian_filter(rng.normal(size=(n,n)),(13,.8),mode='wrap');grain/=grain.std()
        out=out+grain[...,None]*4
    save(name,out)
tile('paving',(197,194,185),2.6,5.2)
tile('granite',(163,170,171),4.1,11,'granite')
tile('gravel',(99,104,104),4,20,'granite')
tile('soil',(104,83,61),6,11,'soil')
tile('wood',(141,92,61),4,5,'wood')
tile('slate',(90,96,95),7,10,'granite')
tile('wall',(170,165,151),6,5)
tile('masonry',(206,207,198),2,5)
tile('tileblue',(120,151,181),3.2,4.7)
tile('brick',(157,114,91),4.5,6)
# Photographic grass grain, stitched with reflected boundaries and multiscale variation.
def mirrored(p):
    return np.concatenate([np.concatenate([p,p[:,::-1]],1),np.concatenate([p[::-1],p[::-1,::-1]],1)],0)
grain=mirrored(ref[651:695,718:770]).astype(float)
def grassgrain(x,y):
    g0=nd.map_coordinates(grain.mean(2),[y%grain.shape[0],x%grain.shape[1]],order=1,mode='wrap')
    return g0-np.mean(grain)
n=512; yy,xx=np.mgrid[:n,:n]
g=grassgrain(xx*.69,yy*.66)
cl=np.array([87.,107.,50.])[None,None,:]+(.64*g+7*field(n,14)+3*field(n,2))[...,None]
save('groundgrass',cl)
# Surface height and plan are shared with Blender.
def turfz(x,y):
    return 2.06+.08*np.sin(x*.32+y*.11)*np.cos(y*.33)-.19*np.exp(-((x-1.)**2/35+(y-1.8)**2/28))+.06*np.sin(.17*y-.3*x)
def proj(x,y,z):
    D=(y+OY)*C+(H-z)*S
    return CX+F*(x+OX)/D,CY-F*((y+OY)*S+(z-H)*C)/D
N=1280
iy,ix=np.mgrid[:N,:N];x=ix/(N-1)*30-15;y=(1-iy/(N-1))*32-17
u,v=proj(x,y,turfz(x,y))
cloned=Image.new('L',(1280,960));d=ImageDraw.Draw(cloned)
for poly in [[(464,674),(470,632),(527,617),(567,610),(595,595),(616,568),(651,557),(689,564),(710,574),(751,579),(756,599),(737,624),(687,629),(660,620),(614,641),(583,670)],[(562,572),(564,547),(612,541),(717,545),(761,557),(764,573),(706,582),(640,579)],[(509,558),(515,526),(523,520),(528,554)],[(572,550),(577,526),(584,523),(591,550)],[(703,548),(710,524),(718,523),(722,552)]]:
    d.polygon(poly,fill=255)
mask=np.asarray(cloned.filter(ImageFilter.GaussianBlur(3.8)))/255
sample=lambda a:nd.map_coordinates(a.astype(float),[v,u],order=1,mode='nearest')
actual=np.stack([sample(ref[:,:,j]) for j in range(3)],2)
alpha=sample(mask)
ca,sa=np.cos(.14),np.sin(.14)
lx=(x+.14)*ca+(y+1.07)*sa;ly=-(x+.14)*sa+(y+1.07)*ca
rad=np.sqrt((lx/11.95)**2+(ly/11.90)**2)
alpha=np.maximum(alpha,np.clip((rad-.94)/.048,0,1))
# Neutralized masonry pixels along the turf lip have individual 3D replacements.
muted=actual[:,:,1]-.50*(actual[:,:,0]+actual[:,:,2])
alpha=np.maximum(alpha,np.clip((11-muted)/8,0,1)*np.clip((rad-.65)/.1,0,1))
patch=grassgrain(x*23+y*2+44,y*22-x*1.8+289)
local=nd.gaussian_filter(actual,18)
base=np.zeros_like(actual)+np.array([91,107,53])
base=.83*base+.17*local
tone=4.7*field(N,34)+2.5*field(N,9)
repair=base+(patch*.77+tone)[:,:,None]
out=actual*(1-alpha[:,:,None])+repair*alpha[:,:,None]
out+=rng.normal(0,1.5,(N,N,1))
save('turf_unique',out)
# Neutral, bluish and cream individual radial inlays from the unoccluded near lawn.
Y,X=np.mgrid[:960,:1280];rr=ref.astype(float)
white=(rr[:,:,0]>116)&(rr[:,:,1]>121)&(rr[:,:,2]>78)&(rr.mean(2)>129)&((rr[:,:,1]-rr[:,:,2])<56)
z=2.06; k=(H-z)/(S-(CY-Y)/F*C+1e-10)
wx=(X-CX)/F*k-OX;wy=(C+(CY-Y)/F*S)*k-OY
llx=(wx+.14)*ca+(wy+1.07)*sa;lly=-(wx+.14)*sa+(wy+1.07)*ca
rad=np.sqrt((llx/11.95)**2+(lly/11.9)**2)
white &= (rad>.69)&(rad<1.015)&(Y>678)&(Y<789)&(lly<-2.7)
labels,num=nd.label(white);stones=[]
for j,bounds in enumerate(nd.find_objects(labels),1):
    if bounds is None:continue
    yy0,xx0=np.where(labels[bounds]==j)
    if not 4<=len(xx0)<=190:continue
    bx=xx0+bounds[1].start;by=yy0+bounds[0].start
    coords=np.stack([wx[by,bx],wy[by,bx]],1);mid=coords.mean(0);vec=mid-np.array([-.14,-1.07]);vec/=np.linalg.norm(vec)
    length=max(.12,min(.88,np.ptp(coords@vec)+.04))
    width=max(.055,min(.21,np.ptp(coords@np.array([-vec[1],vec[0]]))+.035))
    stones.append([*mid.tolist(),float(length),float(width),rgb if (rgb:=float(rr[by,bx].mean())) else 150])
(root/'inlays.json').write_text(json.dumps(stones))
# Draw leaf sprays with individual tapering leaf blades, central veins and secondary branches.
def spray(name,cedar=False,gold=False):
    r=random.Random(name);n=512
    im=Image.new('RGBA',(n,n));dd=ImageDraw.Draw(im)
    def line(a,b,col,w):dd.line((a,b),fill=col,width=max(1,round(w)))
    def leaf(cx,cy,ang,l,w,tone):
        dx,dy=math.cos(ang),math.sin(ang);sx,sy=-dy,dx
        pts=[(cx+dx*l*q+sx*w*k,cy+dy*l*q+sy*w*k) for q,k in [(0,0),(.25,.62),(.59,1),(.82,.52),(1,0),(.7,-.72),(.35,-.88)]]
        pal=np.array([149,161,43] if gold else [76,112,51])+np.array([1,.95,.58])*tone
        col=tuple(np.clip(pal,0,255).astype(int))+(255,)
        dd.polygon(pts,fill=col)
        if l>11:
            line((cx,cy),(cx+l*dx*.86,cy+l*dy*.86),tuple(min(255,int(a+10)) for a in col[:3])+(255,),1.2)
    def frond(x,y,ang,length,width):
        dx,dy=math.cos(ang),math.sin(ang)
        line((x,y),(x+dx*length,y+dy*length),(70,81,44,255),2.5)
        count=25 if cedar else 5
        for i in range(count):
            t=(i+r.uniform(.1,.7))/count
            for side in [-1,1]:
                a=ang+side*r.uniform(.54,1.03)
                l=length*(1-.65*t)*r.uniform(.15,.36) if cedar else width*r.uniform(.64,1.13)*(1-.38*t)
                if cedar:
                    v=r.randint(-17,27);c=(48+v,88+v,63+v,255)
                    line((x+dx*length*t,y+dy*length*t),(x+dx*length*t+l*math.cos(a),y+dy*length*t+l*math.sin(a)),c,1.9)
                else:leaf(x+dx*length*t,y+dy*length*t,a,l,l*r.uniform(.17,.27),r.uniform(-23,42))
    for side in [-1,1]:
        for i in range(10 if cedar else 9):
            t=(i+.45+r.uniform(-.1,.1))/10
            xx=254+10*math.sin(t*4);yy=491-t*438
            l=(194-125*t)*r.uniform(.82,1.12)
            a=-math.pi/2+side*r.uniform(.76,1.25)
            end=(xx+l*math.cos(a),yy+l*math.sin(a))
            line((xx,yy),end,(73,80,47,255),max(2,5*(1-t)))
            if cedar:
                for j in range(8):
                    s=(j+.2)/8
                    for ss in [-1,1]:
                        frond(xx+l*s*math.cos(a),yy+l*s*math.sin(a),a+ss*r.uniform(.35,.82),(1-s*.55)*r.uniform(29,62),7)
            else:
                for j in range(3):
                    s=(j+.25)/3
                    for ss in [-1,1]:
                        frond(xx+l*s*math.cos(a),yy+l*s*math.sin(a),a+ss*r.uniform(.3,.92),r.uniform(25,55),r.uniform(14,24))
    line((254,506),(254,90),(72,79,44,255),3.5)
    frond(254,98,-math.pi/2,83,20)
    # Extend edge colour into transparent texels for clean mipmap edges.
    a=np.array(im);bg=a[:,:,3]==0
    idx=nd.distance_transform_edt(bg,return_distances=False,return_indices=True)
    a[bg,:3]=a[idx[0][bg],idx[1][bg],:3]
    Image.fromarray(a).save(dst/(name+'.png'),optimize=True)
for nm in ['leaf_a','leaf_b','leaf_gold','cedar']:spray(nm,nm=='cedar',nm=='leaf_gold')
# Close foliage textures for the opaque mass among the individual terminal sprays.
for nm,area,tint in [('crown',(263,608,291,634),(0,0,0)),('crown_gold',(1148,805,1185,835),(0,0,0)),('crown_cedar',(773,341,801,370),(0,0,0))]:
    l,t,r,b=area;p=mirrored(ref[t:b,l:r].astype(float))
    y,x=np.mgrid[:384,:384];q=p[(y*.48).astype(int)%p.shape[0],(x*.48).astype(int)%p.shape[1]]
    q=q+field(384,7)[:,:,None]*6
    save(nm,q)
# Rectified, perspective-correct window panes based on two visible stretches of facade.
for nm,wx0,y0,z0,w,h in [('window_w',-32.6,8.75,.51,2.25,3.50),('window_e',30.55,18.55,9.05,2.12,2.1)]:
    n=256;yy,xx=np.mgrid[:n,:n]; y=y0+(xx/(n-1)-.5)*w;z=z0+(1-yy/(n-1))*h
    u,v=proj(np.ones_like(y)*wx0,y,z)
    a=np.stack([nd.map_coordinates(ref[:,:,j].astype(float),[v,u],order=1,mode='nearest') for j in range(3)],axis=2)
    # Keep pane tones, avoid baking a second set of strong mechanical frames.
    a=nd.gaussian_filter(a,(3.2,3.2,0));a=np.clip(a,np.array([32,41,43]),np.array([132,148,147]))
    save(nm,a)
print('Surface textures written, mapped inlays',len(stones))
