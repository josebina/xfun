import sys
sys.path.insert(0,'/workspace/scratch/garden')
from common import *
from ground import create_ground,create_mound
from pavilion import pavilion
from architecture import architecture,rear_garden,photographic_fronts
from planting import create_plants
from activity import activity
for name,fn in [('ground',create_ground),('mound',create_mound),('pavilion',pavilion),('architecture',architecture),('visible elevations',photographic_fronts),('rear courts',rear_garden),('planting',create_plants),('activity',activity)]:
    print('BUILD',name,flush=True);fn()
world=bpy.data.worlds.new('天空 | 柔和日光');scene.world=world;world.use_nodes=True
nodes=world.node_tree.nodes;links=world.node_tree.links;bg=nodes.get('Background')
bg.inputs['Color'].default_value=(.76,.84,.92,1);bg.inputs['Strength'].default_value=1.00
back=nodes.new('ShaderNodeBackground');back.inputs['Color'].default_value=(.84,.85,.81,1);back.inputs['Strength'].default_value=1
mix=nodes.new('ShaderNodeMixShader');rays=nodes.new('ShaderNodeLightPath')
links.new(rays.outputs['Is Camera Ray'],mix.inputs[0]);links.new(bg.outputs[0],mix.inputs[1]);links.new(back.outputs[0],mix.inputs[2]);links.new(mix.outputs[0],nodes.get('World Output').inputs[0])
light=bpy.data.lights.new('柔和夕照','SUN');light.energy=1.24;light.angle=math.radians(24.);light.color=(1,.924,.812)
sun=bpy.data.objects.new('Daylight | 西侧柔光',light);collections['cameras'].objects.link(sun);sun.location=(-35,28,56);sun.rotation_euler=(V((0,0,0))-sun.location).to_track_quat('-Z','Y').to_euler()
def camera(name,loc,direction,typ='PERSP',lens=28.125,ortho=81):
    cp=bpy.data.cameras.new(name);ob=bpy.data.objects.new(name,cp);collections['cameras'].objects.link(ob);ob.location=loc;ob.rotation_euler=V(direction).to_track_quat('-Z','Y').to_euler()
    cp.type=typ;cp.sensor_fit='HORIZONTAL';cp.sensor_width=36;cp.lens=lens;cp.ortho_scale=ortho;cp.clip_end=700
    return ob
loc=(-OX,-OY,H);ori=(0,C,-S)
orig=camera('CAM 01 | 原照片完整画幅',loc,ori)
orig['source_frame_px']='1280 × 960';orig['camera_elevation_m']=H
crop=camera('CAM 02 | 原照片庭院裁切',loc,ori);crop.data.shift_y=(480-(269+886)/2)/1280
iso_loc=(36.3,-66.2,64);at=(0.0,11.5,.55)
iso=camera('CAM 03 | 去楼体轴测',iso_loc,V(at)-V(iso_loc),'ORTHO',ortho=91.0)
detail_loc=(4.0,9.15,6.10);atp=(.3,30.1,2.15)
detail=camera('CAM 04 | 瓦亭与弧廊',detail_loc,V(atp)-V(detail_loc),lens=25)
plan=camera('CAM 05 | 正射平面',(0,11.2,81),(0,0,-1),'ORTHO',ortho=91)
plan.rotation_euler=(0,0,0)
scene.camera=crop
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=9
scene.cycles.use_denoising=False;scene.cycles.adaptive_threshold=.12
scene.cycles.max_bounces=4;scene.cycles.diffuse_bounces=2;scene.cycles.glossy_bounces=2;scene.cycles.transparent_max_bounces=8
scene.cycles.sample_clamp_indirect=3.;scene.render.threads_mode='FIXED';scene.render.threads=2
scene.view_settings.view_transform='Standard';scene.view_settings.exposure=-.10
scene.render.resolution_x=1440;scene.render.resolution_y=694;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
for ar in bpy.context.screen.areas:
    if ar.type=='VIEW_3D':
        sp=ar.spaces.active;sp.region_3d.view_perspective='CAMERA';sp.region_3d.view_camera_zoom=4
        sp.overlay.show_overlays=False;sp.shading.type='SOLID';sp.shading.color_type='MATERIAL';sp.shading.light='STUDIO';sp.clip_end=600
scene['scale_reference']='1 Blender unit = 1 m; four approximate standing silhouettes with a nominal height of 1.70 m.'
scene['reconstruction']='Ground-frame, single-view approximation. Central mound axes at toe 26.6 x 29.6 m. Interpolated surfaces and occluded areas are hypotheses.'
scene['source_location']='地点未核实；坐标轴按拍摄方向设定。'
bpy.ops.file.pack_all()
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'庭院.blend'),compress=True)
print('SAVED',flush=True)
stats={k:len(v.objects) for k,v in collections.items()};(ROOT/'counts.json').write_text(json.dumps(stats))
