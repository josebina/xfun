import math, numpy as np
from scipy.optimize import least_squares
F=1000.; HP=137.; CX=640.; CY=480.
A=math.atan((CY-HP)/F); C=math.cos(A); S=math.sin(A)
def raw(u,v,z=0,h=1):
 k=(h-z)/(S-(CY-v)/F*C)
 return np.array([(u-CX)/F*k,(C+(CY-v)/F*S)*k])
def project(x,y,z,H):
 d=y*C+(H-z)*S
 return [CX+F*x/d,CY-F*(y*S+(z-H)*C)/d]
def estimate(fv,hv):
 def resid(h):
  x,y=raw(640,fv,0,float(h[0]))
  return project(x,y,1.7,h[0])[1]-hv
 return least_squares(resid,[25]).x[0]
if __name__=='__main__':
 for name,fv,hv in [('near',837,799),('left',622,595),('orange',561,535),('far black',556,531),('far light',581,556)]: print(name,estimate(fv,hv))
H=25.3
def fitell():
 pts=[(650,858),(548,847),(471,817),(419,780),(392,738),(381,700),(384,672),(400,636),(425,608),(463,581),(501,562),(548,548),(600,538),(644,534),(700,537),(748,547),(800,563),(838,584),(874,612),(897,641),(913,675),(921,710),(916,743),(897,779),(864,807),(818,830),(740,851)]
 p=np.array([raw(u,v,h=H) for u,v in pts])
 fun=lambda q: ((p[:,0]-q[0])/q[2])**2+((p[:,1]-q[1])/q[3])**2-1
 return least_squares(fun,[.5,47,13,14]).x
OX,OY,RX,RY=fitell()
def xy(u,v,z=0):return raw(u,v,z,H)-[OX,OY]
if __name__=='__main__':
 print('mound',OX,OY,RX,RY)
 for u,v in [(651,858),(382,699),(920,710),(650,534),(267,728),(1014,727),(365,584),(952,601),(151,853),(213,792),(570,473),(731,474),(408,520),(880,526),(643,458),(647,432),(335,396),(1197,620),(9,650),(639,886),(1034,887),(390,528),(916,531)]:
  print(u,v,xy(u,v).round(2))
