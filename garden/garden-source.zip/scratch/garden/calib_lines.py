from ctypes import *
import numpy as np
from PIL import Image
core=CDLL('libopencv_core.so.410')
ip=CDLL('libopencv_imgproc.so.410')
class Sz(Structure): _fields_=[('w',c_int),('h',c_int)]
class Seq(Structure): _fields_=[('flags',c_int),('hdr',c_int),('hp',c_void_p),('hn',c_void_p),('vp',c_void_p),('vn',c_void_p),('total',c_int)]
class Seg(Structure): _fields_=[('x',c_int),('y',c_int),('u',c_int),('v',c_int)]
def fun(lib,n,r,*a):
 f=getattr(lib,n); f.restype=r; f.argtypes=a;return f
head=fun(core,'cvCreateImageHeader',c_void_p,Sz,c_int,c_int)
setd=fun(core,'cvSetData',None,c_void_p,c_void_p,c_int)
canny=fun(ip,'cvCanny',None,c_void_p,c_void_p,c_double,c_double,c_int)
storage=fun(core,'cvCreateMemStorage',c_void_p,c_int)
hough=fun(ip,'cvHoughLines2',POINTER(Seq),c_void_p,c_void_p,c_int,c_double,c_double,c_int,c_double,c_double,c_double,c_double)
get=fun(core,'cvGetSeqElem',POINTER(Seg),c_void_p,c_int)
img=np.array(Image.open('reference.jpg').convert('L'))
ed=np.zeros_like(img)
def cv(a):
 h,w=a.shape; p=head(Sz(w,h),8,1);setd(p,a.ctypes.data,w);return p
src=cv(img);out=cv(ed);canny(src,out,50,110,3);st=storage(0);seq=hough(out,st,1,1,np.pi/720,24,30,8,0,np.pi)
lines=[]
for i in range(seq.contents.total):
 s=get(seq,i).contents
 lines.append([s.x,s.y,s.u,s.v])
np.save('lines.npy',lines)
vv=[];dp=[]
for x,y,u,v in lines:
 dx=u-x;dy=v-y
 xx=(x+u)/2; yy=(y+v)/2
 if abs(dy)>75 and abs(dx/dy)<.33 and ((xx<320 and yy>250) or (xx>975 and yy<660)):
  if dx and 2000<y+(640-x)*dy/dx<8500:vv.append([x,y,u,v,round(y+(640-x)*dy/dx)])
 if abs(dx)>85 and .15<abs(dy/dx)<1.5 and (xx<380 or xx>970) and 80<y+(640-x)*dy/dx<210:dp.append([x,y,u,v,round(y+(640-x)*dy/dx)])
print('vertical',vv[:65]);print('depth',dp[:55])
