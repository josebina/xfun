import json,struct,collections
import numpy as np
from pathlib import Path
p=Path('/workspace/花园重建/庭院.glb');raw=p.read_bytes();magic,version,length=struct.unpack_from('<4sII',raw);assert magic==b'glTF' and version==2 and length==len(raw)
size,tag=struct.unpack_from('<I4s',raw,12);j=json.loads(raw[20:20+size]);off=20+size;binlen,bintag=struct.unpack_from('<I4s',raw,off);data=memoryview(raw)[off+8:];assert bintag==b'BIN\x00' and len(data)==binlen
counts=collections.Counter(n.get('extras',{}).get('model_group') for n in j['nodes'] if 'mesh' in n)
tri=[]
for mesh in j['meshes']:
 total=0
 for prim in mesh['primitives']:
  a=j['accessors'][prim['attributes']['POSITION']]
  assert np.isfinite(np.r_[a['min'],a['max']]).all()
  count=j['accessors'][prim['indices']]['count'] if 'indices' in prim else a['count']
  assert count%3==0;total+=count//3
 tri.append(total)
for i in j['images']:assert 'bufferView' in i and 'uri' not in i
for v in j['bufferViews']:assert v.get('byteOffset',0)+v['byteLength']<=binlen
print('export statistics',counts,'unique meshes',len(tri),'unique triangles',sum(tri),'placed triangles',sum(tri[n['mesh']] for n in j['nodes'] if 'mesh' in n),'textures',len(j['images']),'materials',len(j['materials']))
for m in j['materials']:
 if m['name'].startswith(('L01','L02','L03','L04')):print(m['name'],m.get('alphaMode'),m.get('alphaCutoff'),m.get('pbrMetallicRoughness'))
stat={'groups':dict(counts),'meshes':len(tri),'triangles_unique':sum(tri),'triangles_placed':sum(tri[n['mesh']] for n in j['nodes'] if 'mesh' in n),'textures':len(j['images']),'materials':len(j['materials'])};Path('verified.json').write_text(json.dumps(stat))
