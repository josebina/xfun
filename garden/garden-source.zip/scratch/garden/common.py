import bpy, sys, os, math, json, random
from math import sin, cos, pi, atan2, sqrt
from mathutils import Vector
from pathlib import Path
import numpy as np
ROOT=Path('/workspace/scratch/garden')
OUT=Path('/workspace/花园重建')
SOURCES=ROOT/'textures'
rng=random.Random(4903)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene
scene.name='庭院 | 单像透视重建'
scene.unit_settings.system='METRIC'
scene.unit_settings.length_unit='METERS'
scene.unit_settings.scale_length=1
bpy.context.preferences.filepaths.save_version=0
F=1000.;H=25.3;OX=.5278084693;OY=46.3218155083
PITCH=math.atan(.343);C=cos(PITCH);S=sin(PITCH)
M=(-.14,-1.07);PHI=.14
def xy(u,v,z=0):
    k=(H-z)/(S-(480-v)/F*C)
    return ((u-640)/F*k-OX,(C+(480-v)/F*S)*k-OY)
def proj(x,y,z=0):
    d=(y+OY)*C+(H-z)*S
    return (640+F*(x+OX)/d,480-F*((y+OY)*S+(z-H)*C)/d)
def turfz(x,y):
    return 2.06+.08*sin(x*.32+y*.11)*cos(y*.33)-.19*math.exp(-((x-1.)**2/35+(y-1.8)**2/28))+.06*sin(.17*y-.3*x)
def rot(x,y,a):return (x*cos(a)-y*sin(a),x*sin(a)+y*cos(a))
def around(rx,ry,t):
    x,y=rot(rx*cos(t),ry*sin(t),PHI)
    return (M[0]+x,M[1]+y)
def smooth(t):return t*t*(3-2*t)
collections={}
for k,n in [('site','01 地面 · 铺装与模块花池'),('mound','02 中心 · 草坡与片石'),('pavilion','03 构筑 · 瓦亭与双翼弧廊'),('water','04 水景 · 池岸与步桥'),('furniture','05 设施 · 坐凳与庭园灯'),('plants','06 绿化 · 乔灌木与地被'),('activity','07 可隐藏 · 人物与临时搭建'),('buildings','08 环境 · 教学楼可见立面'),('backtrees','09 环境 · 后排树阵'),('cameras','10 摄影机与日光')]:
    coll=bpy.data.collections.new(n);scene.collection.children.link(coll);collections[k]=coll
mats={};tile_size={}
def lin(v):
    u=max(0,min(255,v))/255
    return u/12.92 if u<=.04045 else ((u+.055)/1.055)**2.4
def mat(name,col,rough=.76,texture=None,tile=1.,metal=0.,clip=False):
    if name in mats:return name
    m=bpy.data.materials.new(name);m.use_nodes=True
    if isinstance(col,str):
        h=col.strip('#');col=tuple(int(h[i:i+2],16) for i in [0,2,4])
    c=tuple(lin(v) for v in col)+(1.,)
    m.diffuse_color=c;nodes=m.node_tree.nodes;links=m.node_tree.links
    bs=nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=c
    bs.inputs['Roughness'].default_value=rough;bs.inputs['Metallic'].default_value=metal
    if name.startswith(('G','L','B','S')):bs.inputs['Specular IOR Level'].default_value=.16
    if texture:
        tex=nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(SOURCES/texture),check_existing=True)
        tex.location=(-400,240);tex.label='嵌入式色彩图'
        links.new(tex.outputs['Color'],bs.inputs['Base Color'])
        if clip:
            test=nodes.new('ShaderNodeMath');test.operation='GREATER_THAN';test.inputs[1].default_value=.38
            links.new(tex.outputs['Alpha'],test.inputs[0]);links.new(test.outputs[0],bs.inputs['Alpha'])
            m.surface_render_method='DITHERED'
            m.use_backface_culling=False
    mats[name]=m;tile_size[name]=tile
    return name
pave=mat('P01  原色浅灰混凝土','#c8c5ba',.89,'paving.jpg',3.6)
gran=mat('P02  芝麻灰花岗岩','#a9acad',.73,'granite.jpg',1.05)
grav=mat('P03  深灰砾石','#6c7370',.94,'gravel.jpg',1.05)
soil=mat('P04  表土与落叶','#66543c',.96,'soil.jpg',1.45)
grass=mat('G01  庭园草皮','#586b39',.96,'groundgrass.jpg',1.9)
turf=mat('G02  照片校正草坪色图','#61733e',.97,'turf_unique.jpg')
paver=mat('P05  米灰步石','#cbc6b6',.86,'paving.jpg',1.25)
edge=mat('P06  灰褐分缝','#98968e',.92)
sub=mat('P07  基座切面','#948f7e',.92)
lightstone=mat('P08  浅灰石缘','#c2c3b6',.8)
darkstone=mat('P09  深灰池壁','#505953',.88)
wet=mat('W01  深绿静水','#38443b',.16,metal=.22)
silt=mat('W02  水面微纹','#4e584c',.26,metal=.15)
metal=mat('M01  石墨色金属','#353b3d',.48,metal=.34)
steel=mat('M02  冷灰金属','#909b9b',.47,metal=.43)
silver=mat('M03  浅灰廊架','#b7bdba',.66,metal=.16)
wood=mat('T01  原色木条','#906247',.7,'wood.jpg',1.2)
redwood=mat('T02  栗褐木扶手','#935e40',.62)
terr=mat('P10  红褐铺地','#94705a',.85,'brick.jpg',2.1)
slatbase=mat('S00  石坡底层','#5b6259',.9,'slate.jpg',1.3)
slates=[mat('S%02d  劈裂片石'%(i+1),col,.84) for i,col in enumerate(['#495153','#555951','#636969','#4a5359','#717b7e','#848b88','#3f4544','#666558','#a1a4a0','#595c54','#747673','#606c71','#8f9084','#55514c'])]
inlay=[mat('I%02d  草中浅色石条'%i,col,.79) for i,col in enumerate(['#b7b5a2','#d1ccb4','#a5a99c','#929989','#d7d3c4','#8c9185'])]
cover=[mat('G1%d  黄绿地被'%i,col,.91) for i,col in enumerate(['#879326','#98a83b','#7f8b25','#adad3e','#b7ba53','#748424','#929f38','#a4b33e'])]
barks=[mat('B0%d  树皮'%i,col,.93) for i,col in enumerate(['#6a6351','#555342','#776d55','#494b3e'])]
wash=mat('B05  树干白色涂层','#c7c7b1',.9)
def V(a):return Vector(a)
def unit(a):
    w=V(a);return w.normalized() if w.length else V((1,0,0))
class Mesh:
    def __init__(self):
        self.v=[];self.faces=[];self.mi=[];self.sm=[];self.uv={};self.slots=[];self.slotids={}
    def points(self,pts):
        idx=len(self.v);self.v.extend(tuple(p) for p in pts);return list(range(idx,len(self.v)))
    def face(self,ids,m,s=False,uv=None):
        if m not in self.slotids:
            self.slotids[m]=len(self.slots);self.slots.append(m)
        if uv is not None:self.uv[len(self.faces)]=uv
        self.faces.append(tuple(ids));self.mi.append(self.slotids[m]);self.sm.append(s)
    def poly(self,pts,m,s=False,uv=None): self.face(self.points(pts),m,s,uv)
    def build(self,name,group):
        if not self.faces:return None
        me=bpy.data.meshes.new(name);me.from_pydata(self.v,[],self.faces);me.materials.clear()
        for m in self.slots:me.materials.append(mats[m])
        me.polygons.foreach_set('material_index',np.asarray(self.mi,dtype=np.int32))
        me.polygons.foreach_set('use_smooth',np.asarray(self.sm,dtype=bool))
        # Vectorized planar UVs for all construction faces, with authored overrides.
        uv=me.uv_layers.new(name='Surface')
        counts=np.fromiter(map(len,self.faces),np.int32);loops=len(me.loops)
        vid=np.empty(loops,dtype=np.int32);me.loops.foreach_get('vertex_index',vid)
        co=np.asarray(self.v,dtype=np.float32)
        co2=co[vid];normals=np.empty(len(self.faces)*3,dtype=np.float32)
        me.polygons.foreach_get('normal',normals);axis=np.repeat(np.abs(normals.reshape(-1,3)).argmax(1),counts)
        til=np.repeat(np.array([tile_size[m] for m in self.slots],np.float32)[self.mi],counts)
        tc=np.empty((loops,2),np.float32)
        tc[:,0]=np.where(axis==0,co2[:,1],co2[:,0])/til
        tc[:,1]=np.where(axis==2,co2[:,1],co2[:,2])/til
        if self.uv:
            starts=np.cumsum(counts)-counts
            for i,v in self.uv.items():tc[starts[i]:starts[i]+counts[i]]=v
        uv.data.foreach_set('uv',tc.ravel());me.update()
        ob=bpy.data.objects.new(name,me);collections[group].objects.link(ob);ob['model_group']=group
        return ob
def box(b,x,y,z,w,d,h,m,ang=0):
    if w<=0 or d<=0 or h<=0:return
    cs=cos(ang);sn=sin(ang)
    p=b.points([(x+u*cs-v*sn,y+u*sn+v*cs,zz) for zz in [z,z+h] for u,v in [(-w/2,-d/2),(w/2,-d/2),(w/2,d/2),(-w/2,d/2)]])
    b.face([p[i] for i in [3,2,1,0]],m);b.face(p[4:],m)
    for j in range(4):b.face([p[j],p[(j+1)%4],p[4+(j+1)%4],p[4+j]],m)
def slab(b,x,y,z,w,d,h,m,bevel=.025,ang=0):
    if bevel<=0:return box(b,x,y,z,w,d,h,m,ang)
    rings=[];cs=cos(ang);sn=sin(ang);bevel=min(bevel,h*.3,w*.12,d*.12)
    for zz,sh in [(z,bevel*.55),(z+bevel,0),(z+h-bevel,0),(z+h,bevel)]:
        a=w/2-sh;c=d/2-sh;t=bevel
        pts=[(-a+t,-c),(a-t,-c),(a,-c+t),(a,c-t),(a-t,c),(-a+t,c),(-a,c-t),(-a,-c+t)]
        rings.append(b.points([(x+u*cs-v*sn,y+u*sn+v*cs,zz) for u,v in pts]))
    b.face(rings[0][::-1],m);b.face(rings[-1],m)
    for r,s in zip(rings,rings[1:]):
        for i in range(8):j=(i+1)%8;b.face([r[i],r[j],s[j],s[i]],m)
def beam(b,p,q,w,d,m):
    a=V(p);c=V(q);direction=unit(c-a)
    side=direction.cross(V((0,0,1)))
    if side.length<.0001:side=V((1,0,0))
    side.normalize();up=direction.cross(side).normalized()
    rr=[]
    for pos in [a,c]:
        rr.append(b.points([pos+side*(w*i/2)+up*(d*j/2) for i,j in [(-1,-1),(1,-1),(1,1),(-1,1)]]))
    a,c=rr;b.face(a[::-1],m);b.face(c,m)
    for i in range(4):j=(i+1)%4;b.face([a[i],a[j],c[j],c[i]],m)
def pipe(b,pts,rad,m,n=8,sm=True):
    if len(pts)<2:return
    pts=[V(p) for p in pts]; rads=[rad]*len(pts) if isinstance(rad,(float,int)) else rad
    rings=[];pre=None
    for i,(p,r) in enumerate(zip(pts,rads)):
        direction=unit(pts[min(i+1,len(pts)-1)]-pts[max(i-1,0)])
        if pre is None:
            pre=V((0,0,1)) if abs(direction.z)<.88 else V((1,0,0))
        e=pre-direction*pre.dot(direction)
        if e.length<.00001:e=direction.cross(V((0,1,0)))
        e.normalize();pre=e;f=direction.cross(e)
        rings.append(b.points([p+r*(cos(2*pi*j/n)*e+sin(2*pi*j/n)*f) for j in range(n)]))
    b.face(rings[0][::-1],m);b.face(rings[-1],m)
    for a,c in zip(rings,rings[1:]):
        for i in range(n):j=(i+1)%n;b.face([a[i],a[j],c[j],c[i]],m,sm)
def rod(b,a,c,r,m,n=7):pipe(b,[a,c],r,m,n)
def rect(b,x1,y1,x2,y2,z,m):
    b.poly([(x1,y1,z),(x2,y1,z),(x2,y2,z),(x1,y2,z)],m)
def pathstrip(b,pts,width,z,m):
    L=[];R=[]
    for j,pt in enumerate(pts):
        prev=pts[max(0,j-1)];nxt=pts[min(len(pts)-1,j+1)]
        dx,dy=nxt[0]-prev[0],nxt[1]-prev[1];l=math.hypot(dx,dy) or 1
        L.append((pt[0]-dy/l*width/2,pt[1]+dx/l*width/2,z))
        R.append((pt[0]+dy/l*width/2,pt[1]-dx/l*width/2,pt[1]*0+z))
    a=b.points(L);c=b.points(R)
    for i in range(len(pts)-1):b.face([a[i],c[i],c[i+1],a[i+1]],m)
def stonepiece(b,base,tip,width,thick,m,r=None):
    r=r or rng;a=V(base);c=V(tip);dir=unit(c-a)
    side=unit((-dir.y,dir.x,0));rr=[]
    for q in [a,c]:
        l=width*.5*r.uniform(.83,1.12);rr.extend([q-side*l+dir*r.uniform(-.027,.024),q+side*l+dir*r.uniform(-.026,.023)])
    pts=[rr[0],rr[2],rr[3],rr[1]]
    if (pts[1]-pts[0]).cross(pts[2]-pts[0]).z<0:pts.reverse()
    ids=b.points(pts+[v+V((0,0,thick*r.uniform(.73,1.19))) for v in pts])
    b.face(ids[4:],m)
    for i in range(4):j=(i+1)%4;b.face([ids[i],ids[j],ids[j+4],ids[i+4]],m)
def oval(b,center,size,m,n=10,lat=6,orient=0):
    x,y,z=center;rx,ry,rz=size;rr=[]
    for i in range(1,lat):
        ph=-pi/2+pi*i/lat;p=[]
        for j in range(n):
            t=2*pi*j/n;xx,yy=rot(rx*cos(t)*cos(ph),ry*sin(t)*cos(ph),orient);p.append((x+xx,y+yy,z+rz*sin(ph)))
        rr.append(b.points(p))
    bot,top=b.points([(x,y,z-rz),(x,y,z+rz)])
    for j in range(n):
        k=(j+1)%n;b.face([bot,rr[0][k],rr[0][j]],m,True);b.face([top,rr[-1][j],rr[-1][k]],m,True)
    for lo,hi in zip(rr,rr[1:]):
        for j in range(n):k=(j+1)%n;b.face([lo[j],lo[k],hi[k],hi[j]],m,True)
def place_shared(proto,name,group,x,y,z=0,scale=(1,1,1),ang=0):
    ob=bpy.data.objects.new(name,proto.data);collections[group].objects.link(ob);ob.location=(x,y,z);ob.scale=scale;ob.rotation_euler.z=ang;ob['model_group']=group;return ob
