import bpy
from pathlib import Path
scene=bpy.context.scene
scene.cycles.use_denoising=False
scene.cycles.samples=28
# Save an editable project that renders with the installed CPU build.
for screen in bpy.data.screens:
    for a in screen.areas:
        if a.type=='VIEW_3D':
            sp=a.spaces.active;sp.shading.type='SOLID';sp.shading.color_type='MATERIAL';sp.overlay.show_overlays=False
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(Path('/workspace/花园重建/庭院.blend')),compress=True)
bpy.ops.export_scene.gltf(filepath='/workspace/花园重建/庭院.glb',export_format='GLB',export_yup=True,export_materials='EXPORT',export_extras=True,export_cameras=False,export_lights=False,export_animations=False)
