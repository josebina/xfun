from calib import *
from scipy.ndimage import map_coordinates,gaussian_filter
from PIL import Image
ref=np.array(Image.open('reference.jpg'),float)
def atlas(name,wx,lo,hi,hh,w,h):
 yy,xx=np.mgrid[:h,:w]
 y=lo+(hi-lo)*xx/(w-1);z=hh*(1-yy/(h-1))
 def sample(y0):
  u,v=project(wx+OX,y0+OY,z,H)
  return np.stack([map_coordinates(ref[...,j],[v,u],order=1,mode='nearest') for j in range(3)],2),u,v
 a,u,v=sample(y)
 if name=='west':
  good=(u>3)&(u<369)&((u<277)|(v<395)|((u<301)&(v<417)))
  yp=5.35+np.remainder(y-5.35,12.50); sf,_,_=sample(yp)
 else:
  good=(u>985)&(u<1276)&((v<347)|(u>1043)&(v<421)|(u>1117)&(v<553)|(u>1199)&(v<649))
  # Avoid the occluding near return and the white left edge of the far wall.
  good &= ~((u>1220)&(y>3.45)&(z<3.5))
  yp=9.6+np.remainder(y-9.6,9.12);sf,_,_=sample(yp)
 mask=gaussian_filter(good.astype(float),1.6)[...,None]
 a=(a*mask+sf*(1-mask))
 a=np.clip(a*1.045+4,0,255).astype(np.uint8)
 Image.fromarray(a).save('textures/facade_'+name+'.jpg',quality=94)
atlas('west',-32.76,-17.1,78.8,10.37,2304,352)
atlas('east',30.68,-19.3,50.65,20.80,2048,768)
# Lift foliage midtones, retaining the dark spaces between leaves.
for nm,inc in [('crown',(16,19,7)),('crown_gold',(13,13,3)),('crown_cedar',(10,13,8))]:
 p='textures/'+nm+'.jpg';a=np.array(Image.open(p)).astype(float)
 Image.fromarray(np.clip(a+np.array(inc),0,255).astype(np.uint8)).save(p,quality=94)
for nm in ['leaf_a','leaf_b','leaf_gold','cedar']:
 p='textures/'+nm+'.png';a=np.array(Image.open(p));a[:,:,:3]=np.clip(a[:,:,:3].astype(float)+np.array([12,12,3] if nm!='cedar' else [6,9,6]),0,255);Image.fromarray(a).save(p)
