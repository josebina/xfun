from pathlib import Path
from PIL import Image
import re,base64,gzip,struct,json,hashlib
out=Path('/workspace/花园重建')
doc=(out/'三维查看器.html').read_text()
m=re.search(r'<script id="compressed-model" type="application/octet-stream">([^<]+)</script>',doc)
decoded=gzip.decompress(base64.b64decode(m.group(1)));assert decoded==(out/'庭院.glb').read_bytes()
assert '__PHOTO__' not in doc and '__POSTER__' not in doc and '__MODEL__' not in doc
for fn in ['原机位对照.jpg','轴测总览.jpg']:
 with Image.open(out/fn) as i: i.verify()
for fn in ['庭院.blend','庭院.glb','景观辨识与尺寸说明.pdf','三维查看器.html','原机位对照.jpg','轴测总览.jpg']:
 p=out/fn;assert p.stat().st_size>10000;print(fn,round(p.stat().st_size/1048576,2),'MiB')
