set -eu
cd /workspace/scratch/garden
for img in match-final.png detail-final.png iso-final.png; do
  python -c 'from PIL import Image;import sys;Image.open(sys.argv[1]).verify()' "$img"
done
OPENBLAS_NUM_THREADS=1 python report_assets.py
python pack_viewer.py
XDG_CONFIG_HOME=/tmp/yard-chrome-conf XDG_CACHE_HOME=/tmp/yard-chrome-cache python report.py
python final_audit.py
pdfinfo '/workspace/花园重建/景观辨识与尺寸说明.pdf' | rg 'Pages|File size'
pdftotext -layout '/workspace/花园重建/景观辨识与尺寸说明.pdf' - | rg '草台纵剖|24.3 m|约 41 m|0.5 m'
pdftoppm -f 3 -l 3 -scale-to 900 -jpeg '/workspace/花园重建/景观辨识与尺寸说明.pdf' check-final
