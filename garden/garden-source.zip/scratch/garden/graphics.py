from pathlib import Path
import math, random
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import patches, font_manager
from calib import *
root=Path(__file__).parent
im=Image.open(root/'reference.jpg').convert('RGB')
fontfile='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
boldfile='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
def labelphoto():
    # Point leaders are drawn on an enlarged crop, preserving the photographic pixels.
    t=305;bottom=886;scale=1.45
    o=im.crop((0,t,1280,bottom)).resize((int(1280*scale),int((bottom-t)*scale)),Image.Resampling.LANCZOS)
    d=ImageDraw.Draw(o);font=ImageFont.truetype(boldfile,round(17*scale))
    pp=[((727,681),(807,720)),((476,787),(389,815)),((872,683),(952,706)),((164,824),(78,783)),((756,495),(788,534)),((654,407),(645,356)),((813,452),(857,400)),((338,510),(271,478)),((596,622),(531,586))]
    for i,(pt,tag) in enumerate(pp,1):
        x,y=pt;cx,cy=tag
        tr=lambda p:(p[0]*scale,(p[1]-t)*scale)
        d.line([tr(pt),tr(tag)],fill='#fffbe8',width=round(3.2*scale))
        d.line([tr(pt),tr(tag)],fill='#30473b',width=round(1.2*scale))
        x,y=tr(pt);r=3.1*scale;d.ellipse((x-r,y-r,x+r,y+r),fill='#e0bc77',outline='#254033',width=2)
        x,y=tr(tag);r=13.4*scale
        d.ellipse((x-r,y-r,x+r,y+r),fill='#314b3c',outline='#f6f4df',width=round(1.6*scale))
        d.text((x,y-.7*scale),str(i),font=font,anchor='mm',fill='white')
    o.save(root/'annotated.jpg',quality=94)
labelphoto()
def cropfile(name,box):im.crop(box).save(root/(name+'.jpg'),quality=97)
cropfile('detail_stone',(392,692,908,855));cropfile('detail_beds',(0,624,295,874));cropfile('detail_roof',(372,386,924,520));cropfile('detail_plant',(255,400,411,589))
# The four photographs use the same pixel enlargement. Brackets mark the chosen head and foot levels.
for name,x,h,f in [('a',993,799,837),('b',356,595,622),('c',869,535,561),('d',806,531,556)]:
    w,hh=49,55;top=f-46;left=x-24
    o=im.crop((left,top,left+w,top+hh)).resize((w*5,hh*5),Image.Resampling.NEAREST);d=ImageDraw.Draw(o)
    for v in [h,f]:d.line((16,(v-top)*5,49,(v-top)*5),fill='#ffeea0',width=3)
    d.line((23,(h-top)*5,23,(f-top)*5),fill='#fff0ab',width=3)
    o.save(root/('ruler_'+name+'.png'))
def wing(sd,t,off=0):
    A=np.array([6.68,30.77]);B=np.array([11.48,29.47]);C0=np.array([16.18,24.62]);D=np.array([17.30,20.04]);k=1-t
    pt=k**3*A+3*k*k*t*B+3*k*t*t*C0+t**3*D;v=3*(k*k*(B-A)+2*k*t*(C0-B)+t*t*(D-C0));n=np.array([-v[1],v[0]])/np.linalg.norm(v)
    x,y=pt+n*off;return (.24+sd*x,y)
def dimension_plan():
    font_manager.fontManager.addfont(fontfile);fp=font_manager.FontProperties(fname=fontfile)
    fig=plt.figure(figsize=(8.5,8.18),dpi=180,facecolor='#f2f2e9');ax=fig.add_axes([.025,.018,.95,.965])
    ax.set_aspect('equal');ax.set_facecolor('#f2f2e9');ax.set_xlim(-37.8,36.8);ax.set_ylim(-26.5,42.4);ax.axis('off')
    def rect(x,y,w,h,color,edge='none',lw=.55,**kw):ax.add_patch(patches.Rectangle((x,y),w,h,facecolor=color,edgecolor=edge,lw=lw,**kw))
    def polygon(ps,col,edge='none',lw=.5,**kw):ax.add_patch(patches.Polygon(ps,closed=True,facecolor=col,edgecolor=edge,lw=lw,**kw))
    def text(x,y,s,size,color='#34463b',**kw):ax.text(x,y,s,fontsize=size,fontproperties=fp,color=color,**kw)
    rect(-33.02,-20.72,63.82,62.7,'#dedbd0','#a8ab9c')
    rect(-37.5,-20.7,4.63,62.7,'#c3c5bb','#a6ac9c');rect(30.68,3.45,5.82,38.52,'#c3c5bb','#a6ac9c');rect(29.72,-19.3,6.78,22.75,'#c3c5bb','#a6ac9c')
    for sd in [-1,1]:
        o=32.7 if sd==-1 else 30.4
        x=np.sort([sd*16.64,sd*o]);rect(x[0],-20.7,x[1]-x[0],40.8,'#b4ae8e')
        x=np.sort([sd*16.64,sd*20.75]);rect(x[0],-20.7,x[1]-x[0],40.8,'#a9b58b')
        for x,w in ([(21.15,.91),(28.33,.74)] if sd<0 else [(21.75,.91),(26.06,.80)]):rect(sd*x-w/2,-20.7,w,40.83,'#ebe8dc')
        for j,y in enumerate(([-16.15,-9.38,-5.48,-.43,4.75,7.35,12.48,17.37] if sd<0 else [-16.31,-10.9,-7.8,-5.8,-2.47,2.68,7.65,12.8,17.12])):
            x=np.sort([sd*(16.65 if j%3 else 20.81),sd*(o-1.13)]);rect(x[0],y-.37,x[1]-x[0],.74,'#e8e4d7')
        def arc(a,b,color,edge='none'):
            pts=[wing(sd,t,a) for t in np.linspace(0,1,55)]+[wing(sd,t,b) for t in np.linspace(1,0,55)];polygon(pts,color,edge)
        arc(3.11,7.60,'#c6a38a');arc(-3.46,-3.10,'#80966d');arc(-3.10,-.34,'#668078','#516a60');arc(-.34,3.12,'#d5c2aa','#8a9687')
        for t in np.linspace(0,1,34):
            a=wing(sd,t,-.5);b=wing(sd,t,3.32);ax.plot([a[0],b[0]],[a[1],b[1]],c='#82958c',lw=.60)
        for t in np.linspace(.015,.985,7):
            for d in [0,2.8]:
                x,y=wing(sd,t,d);rect(x-.13,y-.13,.26,.26,'#526459')
        x=np.sort([.24+1.24*sd,wing(sd,0,-3.10)[0]]);rect(x[0],26.34,x[1]-x[0],1.76,'#668078');rect(x[0],28.1,x[1]-x[0],2.44,'#9caa82')
    for x,y,w,h in [(-24.5,-16.7,5.35,5.70),(-25.7,-3.3,5.35,4.45),(-25.1,7,4.4,3.55),(-27.8,16.4,5.6,4.3),(25.9,-13.05,3,3),(25.9,4.98,3.4,2.7)]:
        rect(x-w/2,y-h/2,w,h,'#7e8984')
        for i in range(6):
            for j in range(5):
                if (i*5+j*17)%8<3:rect(x-w/2+.22+i*(w-.4)/6,y-h/2+.22+j*(h-.4)/5,.35,.35,'#d8d8c9')
    rect(-20.55,-15.63,4.04,3.52,'#627b72','#d9d8c7',1.6)
    for u,v in [(211,805),(276,738),(294,686),(360,611),(403,568),(413,535),(919,574),(927,598),(1016,747),(1079,718),(1032,834)]:
        x,y=xy(u,v);rect(x-.67,y-.47,1.34,.94,'#ccd0c6','#929b8c',.35)
    palettes=[('#bac563','#879150'),('#797f77','#60675e'),('#8a9f66','#738a55')]
    for (rx,ry),(f,e) in zip([(13.32,14.79),(12.69,13.58),(11.95,11.90)],palettes):
        ax.add_patch(patches.Ellipse((-.14,-1.07),2*rx,2*ry,angle=8.02,facecolor=f,edgecolor=e,lw=.7))
    for i in range(162):
        t=2*np.pi*i/162
        def p(rx,ry):
            x=rx*np.cos(t);y=ry*np.sin(t);return np.array([x*np.cos(.14)-y*np.sin(.14)-.14,x*np.sin(.14)+y*np.cos(.14)-1.07])
        a=p(12.00,11.98);b=p(12.65,13.54);ax.plot([a[0],b[0]],[a[1],b[1]],c='#b3b5a2',lw=.21)
    rect(-7.54,30.58,15.56,6.38,'#90a8b4','#596f77',.8)
    for x0 in [-7.54,8.02]:
        x1=x0+(2.45 if x0<0 else -2.45);ax.plot([x0,x1,x0],[30.58,33.77,36.96],c='#e2e2d4',lw=1.)
    ax.plot([-5.09,5.57],[33.77,33.77],c='#d9dfd6',lw=1.0);rect(-2.71,30.2,5.90,7.04,'#92abb9','#596f77',.7)
    ax.plot([-2.71,-1.65,2.13,3.19],[30.2,33.72,33.72,30.2],c='#e6e8d9',lw=.8)
    ax.plot([-2.71,-1.65],[37.24,33.72],c='#dce2da',lw=.8);ax.plot([2.13,3.19],[33.72,37.24],c='#dce2da',lw=.8)
    r=random.Random(8)
    for x,y,rr in [(-17.9,-4.5,2.9),(-16.8,8,3.9),(-28.3,-7.9,1.55),(-28,12.6,1.65),(17.3,5.7,3.85),(17.8,-5.4,3.42),(17.35,-20.38,4.1),(25.45,30.25,3.20)]:
        pts=[]
        for i in range(39):
            t=2*np.pi*i/39;f=r.uniform(.83,1.04);pts.append((x+rr*f*np.cos(t),y+rr*f*np.sin(t)))
        polygon(pts,'#839778','#5d775d',.72,alpha=.72)
        ax.plot(x,y,'.',ms=2.5,c='#526a54')
    # Straight dimension lines, parallel to the fitted ellipse axes.
    def measure(a,b,title,angle,dx=0,dy=0):
        ax.annotate('',b,a,arrowprops=dict(arrowstyle='<->',color='#344a39',lw=.9,shrinkA=0,shrinkB=0,mutation_scale=7))
        mid=(np.array(a)+b)/2;text(mid[0]+dx,mid[1]+dy,title,10,ha='center',va='center',rotation=angle,bbox=dict(boxstyle='round,pad=.16',fc='#f3f3df',ec='none',alpha=.95))
    center=np.array([-.14,-1.07]);u=np.array([np.cos(.14),np.sin(.14)]);v=np.array([-np.sin(.14),np.cos(.14)])
    measure(center-13.32*u,center+13.32*u,'26.6 m',8.02,dx=-4.7,dy=-.62)
    measure(center-14.79*v,center+14.79*v,'29.6 m',-81.98,dx=-.68,dy=4.7)
    text(.24,38.95,'三开间瓦亭',10,ha='center')
    text(-35.21,5,'照片左侧楼体',9,ha='center',rotation=90);text(33.37,5,'照片右侧楼体',9,ha='center',rotation=90)
    for i in range(2):rect(-31.8+5*i,-24.17,5,.48,'#354a3a' if i==0 else '#edf0e3','#354a3a',.45)
    for xx,lab in [(-31.8,'0'),(-26.8,'5'),(-21.8,'10 m')]:text(xx,-25.2,lab,7.5,ha='center')
    text(31.4,-24.8,'近  /  拍摄侧',8,ha='right')
    fig.savefig(root/'plan.png',dpi=180,facecolor=fig.get_facecolor(),pad_inches=0);plt.close(fig)
dimension_plan()
