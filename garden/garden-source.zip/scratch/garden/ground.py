from common import *
def wing(side,t,off=0):
    # Cubic centreline traced on the inner posts. Offsets follow the local normal.
    a,b,c,d=(6.68,30.77),(11.48,29.47),(16.18,24.62),(17.30,20.04)
    k=1-t
    x=k**3*a[0]+3*k*k*t*b[0]+3*k*t*t*c[0]+t**3*d[0]
    y=k**3*a[1]+3*k*k*t*b[1]+3*k*t*t*c[1]+t**3*d[1]
    dx=3*k*k*(b[0]-a[0])+6*k*t*(c[0]-b[0])+3*t*t*(d[0]-c[0])
    dy=3*k*k*(b[1]-a[1])+6*k*t*(c[1]-b[1])+3*t*t*(d[1]-c[1])
    length=math.hypot(dx,dy)
    return (.24+side*(x-dy/length*off),y+dx/length*off)
def ribbon(b,side,a,c,z,m,steps=52,start=0,end=1):
    r=[]
    for i in range(steps+1):
        t=start+(end-start)*i/steps
        p=wing(side,t,a);q=wing(side,t,c)
        r.append(b.points([(*p,z),(*q,z)]))
    for i in range(steps):
        f=[r[i][0],r[i+1][0],r[i+1][1],r[i][1]];b.face(f if side==1 else f[::-1],m)
def headland(b,x1,y1,x2,y2,z,m,holes):
    xs=sorted(set([x1,x2]+[max(x1,min(x2,x)) for h in holes for x in [h[0],h[2]]]))
    ys=sorted(set([y1,y2]+[max(y1,min(y2,y)) for h in holes for y in [h[1],h[3]]]))
    for a,c in zip(xs,xs[1:]):
        for l,r in zip(ys,ys[1:]):
            if not any(h[0]<(a+c)*.5<h[2] and h[1]<(l+r)*.5<h[3] for h in holes):
                rect(b,a,l,c,r,z,m)
def create_ground():
    b=Mesh();box(b,-.98,18.1,-.67,64.15,77.8,.36,sub);b.build('Site | 庭院剖切底座','site')
    pond=(-20.55,-15.63,-16.51,-12.11)
    b=Mesh()
    headland(b,-33.05,-20.78,31.09,17.8,-.005,pave,[pond])
    # Fit the apron to the forward coping of the water feature.
    for sd in [-1,1]:
        line=[(.24,26.30),(.24+sd*1.36,26.30),(wing(sd,0,-3.48)[0]-sd*.35,26.34)]
        line+=[wing(sd,t,-3.48) for t in np.linspace(0,1,51)]
        line+=[(.24+sd*20.5,17.45),(.24+sd*31.1,17.5)]
        for p,q in zip(line,line[1:]):
            face=[(p[0],15.70,.001),(q[0],15.70,.001),(*q,.001),(*p,.001)]
            b.poly(face if sd==1 else face[::-1],pave)
    rect(b,-33.04,17.7,31.08,56.75,-.185,grav)
    rect(b,-33.05,18.0,-20.05,56.8,-.11,grav);rect(b,20.55,17.4,31.09,56.8,-.11,grav)
    rect(b,-33.05,35.8,31.09,56.9,-.1,soil)
    for sd in [-1,1]:
        ribbon(b,sd,-3.52,-3.1,.04,grass)
        ribbon(b,sd,3.07,7.45,.055,terr)
        ribbon(b,sd,7.45,8.15,.038,paver)
        for t in np.linspace(0,1,15):
            p=wing(sd,t,3.09);q=wing(sd,t,7.42)
            pathstrip(b,[p,q],.022,.063,edge)
    rect(b,-8.1,30.4,8.56,39.05,.04,terr)
    # Saw-cut joints are sparse on the central concrete.
    for sd in [-1,1]:
        for y in [-17.7,-12.6,-6.45,.55,7.1,13.85,19.5]:
            x=sd*16.7
            pathstrip(b,[(x,y),(sd*7.9,y+2.65)],.014,.006,edge)
        pathstrip(b,[(sd*1.2,-20.65),(sd*7.9,-13.3)],.013,.006,edge)
    b.build('Hardscape | 环形通道与弧前广场','site')
    b=Mesh();furn=Mesh()
    for sd in [-1,1]:
        inside,outside=(16.60,32.65) if sd==-1 else (16.75,30.52)
        x1,x2=sorted([sd*outside,sd*inside])
        headland(b,x1,-20.7,x2,20.1,.018,soil,[pond] if sd==-1 else [])
        x1,x2=sorted([sd*inside,sd*20.74])
        headland(b,x1,-20.68,x2,19.95,.032,grass,[pond] if sd==-1 else [])
        strips=[(21.15,.91),(28.33,.74)] if sd==-1 else [(21.75,.91),(26.06,.80)]
        for x,w in strips:
            for y0,y1 in [(-20.7,-8.1),(-8.09,5.03),(5.045,20.07)]:
                rect(b,sd*x-w/2,y0,sd*x+w/2,y1,.06,paver)
            for yy in np.arange(-20.1,19.9,1.16):
                rect(b,sd*x-w/2,yy,sd*x+w/2,yy+.016,.062,edge)
        crosses=[(-16.15,20.9,31),(-9.38,16.6,31.6),(-5.48,16.6,28.3),(-.43,16.6,30.9),(4.75,20.7,31.2),(7.35,16.6,27.9),(12.48,16.6,31.5),(17.37,20.8,30.4)] if sd==-1 else [(-16.31,16.7,29.9),(-10.9,21.7,30),(-7.80,16.8,27.1),(-5.8,20.5,29.8),(-2.47,19.9,29.7),(2.68,17.2,29.1),(7.65,16.7,26.1),(12.8,17.1,29.9),(17.12,20.3,29.7)]
        for yy,a,c in crosses:
            xx=sorted((sd*a,sd*c));rect(b,xx[0],yy-.37,xx[1],yy+.37,.061,paver)
            for x in np.arange(xx[0]+.96,xx[1],1.12):rect(b,x,yy-.36,x+.013,yy+.36,.064,edge)
        # Mechanical drainage and grating beside the teaching blocks.
        xx=sd*(32.02 if sd<0 else 29.12)
        rect(b,xx-.39,-20.6,xx+.39,38.5,.049,grav)
        for yy in np.arange(-20.55,38.4,.26):rect(b,xx-.39,yy,xx+.39,yy+.028,.054,steel)
        for yy in np.arange(-19.8,20.0,1.50):
            x=sd*(30.6 if sd<0 else 28.4)
            box(b,x,yy,.043,1.92,.04,.04,lightstone)
        # Gravel carpets with individually inserted contrasting square pavers.
        plates=[(-24.5,-16.7,5.35,5.70),(-25.7,-3.3,5.35,4.45),(-25.1,7.0,4.4,3.55),(-27.8,16.4,5.6,4.3)] if sd<0 else [(25.9,-13.05,3.0,3.0),(25.9,4.98,3.4,2.7)]
        for ix,(cx,cy,w,d) in enumerate(plates):
            box(b,cx,cy,.043,w+.13,d+.13,.045,lightstone);box(b,cx,cy,.078,w,d,.018,grav)
            for col in range(int(w/.63)):
                for row in range(int(d/.65)):
                    if rng.random()<.40:
                        px=cx-w/2+.35+col*.65;py=cy-d/2+.35+row*.66
                        box(b,px,py,.093,rng.choice([.34,.40,.47]),rng.choice([.34,.42,.65]),.022,rng.choice([paver,gran,lightstone]))
    rect(b,-20.56,-20.65,-16.54,-15.76,.072,grav)
    for j in range(41):
        x=rng.uniform(-20.39,-16.79);y=rng.uniform(-20.41,-15.91)
        box(b,x,y,.075,.26,.40,.017,rng.choice([pave,gran]))
    b.build('Parterres | 正交步道、砾石毯、种植池与排水篦','site')
    # Coping, pool walls and the recessed water surface.
    b=Mesh();a,l,c,r=pond;w=c-a;h=r-l
    rect(b,a,l,c,r,-.107,wet)
    for x in [a,c]:
        box(b,x,(r+l)/2,-.32,.16,h+.22,.44,darkstone)
        for y in np.linspace(l,r,6,endpoint=False):slab(b,x,y+h/12,.09,.205,h/6-.018,.075,lightstone,.012)
    for y in [l,r]:
        box(b,(a+c)/2,y,-.32,w,.16,.44,darkstone)
        for x in np.linspace(a,c,7,endpoint=False):slab(b,x+w/14,y,.09,w/7-.018,.21,.075,lightstone,.012)
    b.build('Pool | 左前矩形静水池及分块压顶','water')
    b=Mesh()
    for sd in [-1,1]:
        ribbon(b,sd,-3.11,-.39,-.105,wet)
        for off in [-3.13,-.34]:
            plist=[wing(sd,t,off) for t in np.linspace(0,1,39)]
            for p,q in zip(plist,plist[1:]):beam(b,(*p,-.105),(*q,-.105),.12,.35,darkstone)
            for i in range(24):
                p=wing(sd,(i+.018)/24,off);q=wing(sd,(i+.982)/24,off)
                beam(b,(*p,.102),(*q,.102),.15,.075,lightstone)
        for t in [1]:
            p=wing(sd,t,-3.13);q=wing(sd,t,-.34)
            beam(b,(*p,-.08),(*q,-.08),.16,.34,darkstone);beam(b,(*p,.11),(*q,.11),.19,.08,lightstone)
        inner=wing(sd,0,-3.13);outer=wing(sd,0,-.34)
        join_x=wing(sd,0,-3.48)[0]-sd*.35
        front=(join_x,26.35);rear=(join_x,28.10)
        wedge=[(*front,-.105),(*inner,-.105),(*outer,-.105),(*rear,-.105)]
        b.poly(wedge if sd>0 else wedge[::-1],wet)
        for p,q in [(front,inner),(rear,outer)]:
            beam(b,(*p,-.10),(*q,-.10),.13,.34,darkstone);beam(b,(*p,.10),(*q,.10),.17,.075,lightstone)
        e=(join_x,28.10);axis=.24+sd*1.24
        # Straight pools open visually to the curved wings beside the central footbridge.
        xa,xb=sorted([axis,e[0]]);rect(b,xa,26.34,xb,28.10,-.107,wet)
        for yy in [26.35,28.10]:
            box(b,(xa+xb)/2,yy,-.13,xb-xa,.11,.26,darkstone);box(b,(xa+xb)/2,yy,.012,xb-xa,.15,.065,lightstone)
        xmid=(xa+xb)/2
        box(b,xmid,29.32,-.04,xb-xa,2.44,.28,paver)
        box(b,xmid,29.35,.24,xb-xa-.22,2.20,.075,soil)
    box(b,.24,28.80,-.25,2.48,5.15,.45,pave)
    for yy in np.arange(26.47,31.1,.62):box(b,.24,yy,.20,2.46,.59,.052,paver)
    b.build('Water court | 两翼弧形水渠、中央植池与石桥','water')
    # Limestone seating blocks, with separate undersides and chamfered edges.
    def seat(x,y,w,d,h=.47):
        box(furn,x,y,.024,w*.83,d*.81,h*.37,darkstone);slab(furn,x,y,.024+h*.27,w,d,h*.73,gran,.029)
    for u,v,w,d in [(211,805,2.35,1.31),(233,820,1.48,1.17),(276,738,1.30,.96),(294,686,1.39,.93),(360,611,1.52,1.09),(403,568,1.39,.95),(413,535,1.4,.98),(919,574,1.45,1.1),(927,598,1.35,1.03),(1016,747,1.9,1.28),(1079,718,1.52,1.05),(1032,834,1.7,1.09),(1006,869,1.3,1.0),(129,722,1.10,.87),(63,705,1.12,.92),(47,832,1.16,.9),(129,809,1.16,1.0),(142,666,1.,.85),(207,601,1.05,.85),(229,585,.9,.75),(219,544,.87,.67)]:
        x,y=xy(u,v);seat(x,y,w,d)
    for u,v in [(333,624),(963,625),(159,875),(212,556),(1180,726)]:
        x,y=xy(u,v)
        box(furn,x,y,.06,.19,.20,1.72,metal);box(furn,x,y,1.72,.20,.21,.055,steel)
    for x,y in [(-29.45,2.2),(-29.3,15.8)]:
        for dx in [-.25,.25]:box(furn,x+dx,y,.07,.11,2.72,.34,metal)
        for dx in [-.27,-.135,0,.135,.27]:slab(furn,x+dx,y,.4,.122,2.94,.074,wood,.011)
    furn.build('Furniture | 芝麻灰石凳、木凳与黑色灯柱','furniture')
    # A few irregular mottles at the visible spots on the warm-grey paving.
    b=Mesh();damp=[mat('P12  深色地面斑驳','#8e8c80'),mat('P13  浅色地面斑驳','#aca99d')]
    for u,v,ww,dd in [(1010,769,1.48,.87),(971,837,.46,.41),(649,514,.53,.43),(749,519,.86,.38),(733,516,.62,.33),(701,520,.38,.24)]:
        x,y=xy(u,v);pp=[]
        for t in np.linspace(0,2*pi,25,endpoint=False):
            f=rng.uniform(.76,1.10);pp.append((x+ww*f*cos(t)/2,y+dd*f*sin(t)/2,.008))
        b.poly(pp,rng.choice(damp))
    b.build('Surface marks | 广场斑驳','site')
def crest(t):
    x,y=around(11.95,11.90,t);return (x,y,turfz(x,y))
def outer(t):
    return (*around(13.32+.028*sin(t*7),14.79+.032*cos(t*6),t),.047)
def toe(t):
    return (*around(12.69+.045*sin(t*8),13.58+.06*cos(t*11),t),.255+.035*sin(t*5))
def slopepoint(t,v):
    a=V(toe(t));c=V(crest(t));p=a.lerp(c,v);p.z+=.07*sin(pi*v)
    return p
def create_mound():
    b=Mesh();N=192;nr=40
    x,y=M;center=b.points([(x,y,turfz(x,y))])[0];rings=[]
    for i in range(1,nr+1):
        r=i/nr;pts=[]
        for j in range(N):
            t=2*pi*j/N;x,y=around(11.95*r,11.9*r,t);pts.append((x,y,turfz(x,y)))
        rings.append(b.points(pts))
    uv=lambda ids:[((b.v[i][0]+15)/30,(b.v[i][1]+17)/32) for i in ids]
    for j in range(N):
        ids=[center,rings[0][j],rings[0][(j+1)%N]];b.face(ids,turf,True,uv(ids))
    for inn,ou in zip(rings,rings[1:]):
        for j in range(N):
            k=(j+1)%N;ids=[inn[j],ou[j],ou[k],inn[k]];b.face(ids,turf,True,uv(ids))
    ob=b.build('Turf | 中央草坪台地 · 照片校色','mound');ob['estimated_crest_height_m']=2.06
    b=Mesh();border=Mesh()
    for j in range(N):
        t=2*pi*j/N;u=2*pi*(j+1)/N
        b.poly([toe(t),toe(u),crest(u),crest(t)],slatbase,True)
        for l in range(4):
            a=.25*l;c=.25*(l+1)
            p0=V(outer(t)).lerp(V(toe(t)),a);p1=V(outer(u)).lerp(V(toe(u)),a)
            p2=V(outer(u)).lerp(V(toe(u)),c);p3=V(outer(t)).lerp(V(toe(t)),c)
            b.poly([p0,p1,p2,p3],cover[0 if sin(t)<0 else 5],True)
        p,q=outer(t),outer(u)
        beam(border,(p[0],p[1],.042),(q[0],q[1],.042),.048,.069,darkstone)
    b.build('Earthwork | 边坡与黄绿地被基层','mound');border.build('Edging | 椭圆坡脚收边','mound')
    b=Mesh()
    # Individual stone splints, arranged by hand-laid radial courses.
    for j in range(678):
        t=2*pi*(j+rng.uniform(-.16,.16))/678
        at=rng.uniform(-.03,.035)
        while at<.99:
            length=rng.uniform(.14,.49);end=min(1.0+rng.uniform(-.015,.02),at+length)
            a=slopepoint(t,at);c=slopepoint(t+rng.uniform(-.0025,.0025),end)
            bump=rng.uniform(.017,.070);a.z+=bump;c.z+=bump
            stonepiece(b,a,c,rng.uniform(.074,.134),rng.uniform(.023,.069),rng.choices(slates,weights=[12,10,12,11,6,5,9,8,2,11,6,8,2,4])[0])
            at=end+rng.uniform(.006,.021)
    photo_slate=mat('S20  迎摄影面片石实景色纹','#606462',.9,'visible_slate.jpg')
    b.slotids[photo_slate]=len(b.slots);b.slots.append(photo_slate)
    for fi,face in enumerate(b.faces):
        pts=[b.v[k] for k in face];x,y,z=pts[0]
        if y>M[1]-.10:continue
        uv=[proj(*p) for p in pts]
        if all(365<u<933 and 565<v<855 for u,v in uv):
            b.mi[fi]=b.slotids[photo_slate];b.uv[fi]=[((u-365)/568,(855-v)/290) for u,v in uv]
    ob=b.build('Revetment | 放射状劈裂片石','mound')
    extra=Mesh()
    for k in range(104):
        t=2*pi*k/104+rng.uniform(-.021,.021);p=V(outer(t));q=V(toe(t))
        a=p.lerp(q,rng.uniform(0,.48));c=p.lerp(q,rng.uniform(.68,1));a.z+=.039;c.z+=.04
        stonepiece(extra,a,c,rng.uniform(.038,.073),.035,rng.choice(slates+inlay[:3]))
    moss=[mat('G4%d  石缝草与苔色'%i,c,.96) for i,c in enumerate(['#576536','#68773a','#718043','#78844a','#667139'])]
    for i in range(1250):
        t=rng.uniform(0,2*pi);end=rng.uniform(.71,1.01);p=slopepoint(t,end);q=slopepoint(t+.002,min(1.,end+rng.uniform(.025,.10)));p.z+=.075;q.z+=.098
        stonepiece(extra,p,q,rng.uniform(.023,.085),.024,rng.choice(moss))
    extra.build('Margins | 石坡草缝与穿入地被的石条','mound')
    b=Mesh()
    for x,y,l,w,g in json.loads((ROOT/'inlays.json').read_text()):
        dx=x-M[0];dy=y-M[1];den=math.hypot(dx,dy);ux,uy=dx/den,dy/den
        p=(x-ux*l/2,y-uy*l/2);q=(x+ux*l/2,y+uy*l/2)
        stonepiece(b,(*p,turfz(*p)+.009),(*q,turfz(*q)+.009),w,.026,rng.choice(inlay))
    for ang in [.2,1.1,2.1,2.86,3.5,5.8]:
        for j in range(13):
            t=ang+rng.gauss(0,.064);r=rng.uniform(.90,1.)
            p=around(11.95*r,11.90*r,t);q=around(11.95*(r+.018),11.90*(r+.018),t)
            stonepiece(b,(*p,turfz(*p)+.01),(*q,turfz(*q)+.01),rng.uniform(.07,.15),.018,rng.choice(inlay[2:]))
    b.build('Inlays | 草坪内嵌浅色石条与扇状铺纹','mound')
    b=Mesh()
    for i in range(11300):
        t=rng.uniform(0,2*pi);d=rng.random()
        p=V(outer(t)).lerp(V(toe(t)),d);p.z+=.011
        m=rng.choice(cover if sin(t+PHI)<.42 else [cover[0],cover[5],cover[6]])
        for j in range(rng.randint(2,4)):
            ang=rng.uniform(0,2*pi);rad=rng.uniform(.037,.102);sz=rng.uniform(.018,.046)
            x,y,z=p;xx=x+rad*cos(ang);yy=y+rad*sin(ang);h=rng.uniform(.024,.083)
            b.poly([(x,y,z),(x+.47*rad*cos(ang)-sin(ang)*sz,y+.47*rad*sin(ang)+cos(ang)*sz,z+h),(xx,yy,z+h*.73),(x+.5*rad*cos(ang)+sin(ang)*sz,y+.5*rad*sin(ang)-cos(ang)*sz,z+h*.82)],m,True)
    b.build('Groundcover | 坡脚小叶黄绿地被','mound')
    b=Mesh();blades=[mat('G3%d  草叶'%i,col,.95) for i,col in enumerate(['#758242','#586f32','#697c3f','#91964e','#687939'])]
    for j in range(12800):
        r=sqrt(rng.random());t=rng.random()*2*pi;x,y=around(11.93*r,11.88*r,t);z=turfz(x,y)+.003
        a=rng.uniform(0,2*pi);w=rng.uniform(.007,.019);dx,dy=cos(a)*w,sin(a)*w
        b.poly([(x-dx,y-dy,z),(x+dx,y+dy,z),(x+rng.uniform(-.032,.034),y+rng.uniform(-.035,.035),z+rng.uniform(.025,.083))],rng.choice(blades))
    b.build('Turf detail | 近景草叶','mound')
