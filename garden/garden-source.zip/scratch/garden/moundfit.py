from calib import *
from PIL import Image,ImageDraw
from scipy.ndimage import gaussian_filter1d
im=Image.open('reference.jpg').convert('RGB');img=np.array(im,dtype=float)
d=ImageDraw.Draw(im)
pts1=[];pts2=[]
for deg in np.arange(-20,202,2):
 t=np.deg2rad(deg); rr=np.arange(.62,1.23,.002)
 uu=(650+270*rr*np.cos(t)).astype(int);vv=(693+163*rr*np.sin(t)).astype(int)
 rgb=img[vv,uu];g=rgb[:,1]-.50*(rgb[:,0]+rgb[:,2])
 # detect bright approach to walkway
 lum=rgb.mean(axis=1); w=lum-g*1.45
 res=gaussian_filter1d(w,4,order=1)
 j=np.argmax(np.where(rr>.89,res,-99))
 if res[j]<1.8:continue
 pts1.append((uu[j],vv[j]));d.ellipse((uu[j]-2,vv[j]-2,uu[j]+2,vv[j]+2),fill='red')
 if 6<deg<177:
  # grass to slate around rr .85 on sides and .46 at center-front
  rr=np.arange(.30,1.01,.002)
  uu=(650+270*rr*np.cos(t)).astype(int);vv=(693+163*rr*np.sin(t)).astype(int)
  rgb=img[vv,uu]
  g=rgb[:,1]-.5*(rgb[:,0]+rgb[:,2])
  res=gaussian_filter1d(g,8,order=1)
  est=.89-.44*max(0,np.sin(t))
  j=np.argmin(np.where((rr>est-.12)&(rr<est+.14),res,99))
  if res[j]>-.32:continue
  pts2.append((uu[j],vv[j]));d.ellipse((uu[j]-2,vv[j]-2,uu[j]+2,vv[j]+2),fill='cyan')
def ell(pts,z):
 p=np.array([xy(u,v,z) for u,v in pts])
 def err(q):
  a,b,rx,ry,angle=q
  x=p[:,0]-a;y=p[:,1]-b
  ca,sa=np.cos(angle),np.sin(angle)
  return (((ca*x+sa*y)/rx)**2+((-sa*x+ca*y)/ry)**2-1)*8
 return least_squares(err,[0,0,13,16,.02],loss='soft_l1',f_scale=.07).x
print('base',ell(pts1,0))
for z in [0,1,1.5,2,2.5]:print('crest',z,ell(pts2,z))
print('points',len(pts1),len(pts2))
im.crop((375,528,927,866)).save('fitm.jpg')
a,b,rx,ry,phi=ell(pts1,0)
more=[(650,535),(611,537),(574,544),(709,541),(748,549),(783,561),(407,662),(899,677),(405,672),(899,665),(417,640),(890,640)]
p0=np.array([raw(u,v,h=H) for u,v in pts2+more])
def err(q):
 rx2,ry2,z=q
 p=p0*(1-z/H)-[OX+a,OY+b];x,y=p.T
 ca,sa=np.cos(phi),np.sin(phi)
 return (np.sqrt(((ca*x+sa*y)/rx2)**2+((-sa*x+ca*y)/ry2)**2)-1)*13
fit=least_squares(err,[11.8,13.5,1.7],loss='soft_l1',f_scale=.16);print('joint',fit.x,np.median(abs(fit.fun)))
