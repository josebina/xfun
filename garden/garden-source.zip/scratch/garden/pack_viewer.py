import base64,gzip,io
from PIL import Image
from pathlib import Path
ROOT=Path(__file__).parent
OUT=Path('/workspace/花园重建')
def uri(fn,resample=False):
    if resample:
        im=Image.open(fn).convert('RGB');im.thumbnail((1360,840));s=io.BytesIO();im.save(s,'JPEG',quality=88);raw=s.getvalue()
    else:raw=Path(fn).read_bytes()
    return 'data:image/jpeg;base64,'+base64.b64encode(raw).decode()
s=(ROOT/'viewer_template.html').read_text()
for key,n in [('THREE','build/three.min.js'),('LOADER','examples/js/loaders/GLTFLoader.js'),('CONTROLS','examples/js/controls/OrbitControls.js')]:
    s=s.replace('__'+key+'__',(ROOT/'package'/n).read_text())
s=s.replace('__MODEL__',base64.b64encode(gzip.compress((OUT/'庭院.glb').read_bytes(),compresslevel=6,mtime=0)).decode())
s=s.replace('__PHOTO__',uri(ROOT/'reference.jpg')).replace('__POSTER__',uri(ROOT/('match_render.jpg' if (ROOT/'match_render.jpg').exists() else 'test-match.png'),True))
s=s.replace('</head>','<!-- Three.js, GLTFLoader & OrbitControls. '+(ROOT/'package/LICENSE').read_text().replace('--','–')+' -->\n</head>')
(OUT/'三维查看器.html').write_text(s)
