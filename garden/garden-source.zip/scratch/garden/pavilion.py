from common import *
from ground import wing,ribbon
def pavilion():
    colmat=mat('A01  灰色亭柱','#8c9390',.81)
    soffit=mat('A02  亭底深灰木作','#566360',.77)
    roofbase=mat('A03  蓝灰瓦底','#829db8',.67,'tileblue.jpg',1.5)
    ribs=[mat('A1%d  釉面筒瓦'%i,col,.51,.0 if False else None) for i,col in enumerate(['#8da8c1','#a0b5c7','#819bb5','#98b1c8','#7694b0'])]
    ridge=mat('A04  银灰脊瓦','#c2c9c7',.56,metal=.12)
    joist=mat('A05  廊架阴影灰','#899592',.72)
    floor=Mesh();frame=Mesh();tiles=Mesh();details=Mesh();rail=Mesh();benches=Mesh()
    slab(floor,.24,33.70,.105,14.42,5.56,.185,paver,.046)
    for iy in range(5):
        for ix in range(14):
            if (ix+iy)%3==1:continue
            x=-6.42+ix*1.02;y=31.53+iy*1.03
            box(floor,x,y,.287,1.008,1.013,.010,rng.choice([paver,pave]))
    for x in [-6.44,-1.99,2.91,6.91]:
        for y in [31.31,35.86]:
            slab(frame,x,y,.28,.49,.49,.18,gran,.022)
            box(frame,x,y,.42,.313,.313,2.87,colmat)
            slab(frame,x,y,3.04,.43,.44,.22,joist,.025)
            for sd in [-1,1]:
                beam(frame,(x+sd*.12,y,2.73),(x+sd*.61,y,3.24),.105,.15,soffit)
    for y in [31.31,35.86]:
        box(frame,.235,y,3.17,13.69,.22,.23,soffit)
    for x in [-6.44,-1.99,2.91,6.91]:
        box(frame,x,33.59,3.18,.2,4.91,.22,soffit)
    for x in np.arange(-6.72,7.31,.45):
        box(frame,x,33.60,3.33,.087,5.23,.11,joist)
    def roof(cx,cy,hw,hd,ez,rz,ridgelen,raised=False):
        c=[(-hw,-hd),(hw,-hd),(hw,hd),(-hw,hd)]
        r=[(-ridgelen,0),(ridgelen,0),(ridgelen,0),(-ridgelen,0)]
        for face in range(4):
            j=(face+1)%4;p=c[face];q=c[j];ra=r[face];rb=r[j]
            def at(u,v,offset=0):
                ex=p[0]+(q[0]-p[0])*u;ey=p[1]+(q[1]-p[1])*u
                xx=ex*(1-v)+(ra[0]+(rb[0]-ra[0])*u)*v
                yy=ey*(1-v)+(ra[1]+(rb[1]-ra[1])*u)*v
                curl=(.39 if not raised else .17)*(abs(2*u-1)**4)*(1-v)**1.55
                # Upturns concentrate at the hips and fade smoothly into the roof field.
                z=ez+(rz-ez)*(.52*v+.48*v*v)+curl+offset
                return (cx+xx,cy+yy,z)
            width=math.dist(p,q);n=max(11,round(width/.205));rows=13
            grid=[]
            for iy in range(rows+1):grid.append(tiles.points([at(k/n,iy/rows) for k in range(n+1)]))
            for iy in range(rows):
                for k in range(n):
                    a=grid[iy];b=grid[iy+1]
                    if iy==rows-1 and ra==rb:tiles.face([a[k],a[k+1],b[k]],roofbase,True)
                    else:tiles.face([a[k],a[k+1],b[k+1],b[k]],roofbase,True)
            for k in range(1,n):
                u=k/n
                # Individual tile noses stop short of the narrowing hips.
                if ra==rb:
                    limit=max(.18,1-abs(u-.5)*.14)
                else:limit=1.
                pipe(details,[at(u,s*.99*limit,.021) for s in np.linspace(0,1,7)],.038 if not raised else .034,rng.choice(ribs),5)
            for iy in range(1,rows):
                v=iy/rows
                pipe(details,[at(u,v,.017) for u in np.linspace(0,1,15)],.010,ribs[2],5)
            pp=[at(0,s,.056) for s in np.linspace(0,1,14)];pipe(details,pp,.090 if not raised else .084,ridge,9)
            pp=[at(s,0,.023) for s in np.linspace(0,1,29)]
            pipe(details,pp,.073,ridge,8)
            for a,b in zip(pp,pp[1:]):
                beam(frame,(a[0],a[1],a[2]-.123),(b[0],b[1],b[2]-.123),.103,.135,joist)
            # Opaque underside visible from an eye-level camera.
            for sy in range(8):
                for sx in range(10):
                    u0,u1=sx/10,(sx+1)/10;v0,v1=sy/8,(sy+1)/8
                    pts=[at(u0,v0,-.14),at(u0,v1,-.14),at(u1,v1,-.14),at(u1,v0,-.14)]
                    if ra==rb and sy==7:pts.pop(2)
                    frame.poly(pts,soffit)
        rod(details,(cx-ridgelen,cy,rz+.056),(cx+ridgelen,cy,rz+.056),.093,ridge,10)
        for x in np.arange(cx-ridgelen+.15,cx+ridgelen,.35):rod(details,(x-.015,cy,rz+.056),(x+.015,cy,rz+.056),.101,ridge,9)
    roof(.24,33.77,7.78,3.19,3.47,5.15,5.33)
    roof(.24,33.72,2.95,3.52,3.69,5.58,1.89,True)
    for sd in [-1,1]:
        ribbon(floor,sd,-.34,3.13,.164,terr)
        for off in [-.33,3.12]:
            ps=[wing(sd,t,off) for t in np.linspace(0,1,39)]
            for a,b in zip(ps,ps[1:]):
                beam(frame,(*a,.16),(*b,.16),.18,.21,gran)
        for t in np.linspace(.015,.986,7):
            for off in [0,2.80]:
                x,y=wing(sd,t,off)
                slab(frame,x,y,.17,.32,.32,.12,gran,.015)
                box(frame,x,y,.27,.185,.185,2.96,colmat)
                box(frame,x,y,3.10,.25,.25,.16,joist)
            a=wing(sd,t,-.18);b=wing(sd,t,3.02)
            beam(frame,(*a,3.15),(*b,3.15),.14,.15,joist)
        for off in [0,2.8]:
            ps=[wing(sd,t,off) for t in np.linspace(0,1,46)]
            for a,b in zip(ps,ps[1:]):beam(frame,(*a,3.19),(*b,3.19),.185,.215,joist)
        for j in range(34):
            t=(j+.20)/33.55
            # Small bevelled upturn at the projecting louvre ends.
            curve=[(*wing(sd,t,o),z) for o,z in [(-.52,3.40),(-.36,3.35),(.18,3.32),(2.51,3.32),(3.13,3.38),(3.34,3.46)]]
            for a,b in zip(curve,curve[1:]):beam(details,a,b,.115,.153,silver)
        # Inner balustrade, with open access at each wing end.
        for off in [-.06]:
            ps=[wing(sd,t,off) for t in np.linspace(.012,.978,44)]
            for a,b in zip(ps,ps[1:]):
                beam(rail,(*a,1.18),(*b,1.18),.125,.09,redwood)
                beam(rail,(*a,.40),(*b,.40),.063,.045,steel)
            for t in np.linspace(.013,.979,27):
                p=wing(sd,t,off);box(rail,*p,.20,.052,.052,.96,steel)
        for i in range(6):
            # Distinct slatted benches follow the outer railing.
            a=wing(sd,(i+.22)/6,2.15);c=wing(sd,(i+.83)/6,2.15);dx,dy=c[0]-a[0],c[1]-a[1];ll=math.hypot(dx,dy)
            nx,ny=-dy/ll,dx/ll
            if nx*sd<0:nx,ny=-nx,-ny
            for t in [.15,.85]:
                x=a[0]+t*dx;y=a[1]+t*dy
                beam(benches,(x-nx*.24,y-ny*.24,.22),(x+nx*.24,y+ny*.24,.22),.085,.075,metal)
                for o in [-.19,.19]:
                    box(benches,x+nx*o,y+ny*o,.19,.072,.072,.40,metal)
                beam(benches,(x+nx*.23,y+ny*.23,.50),(x+nx*.32,y+ny*.32,.99),.067,.061,metal)
            for o in [-.21,-.10,.01,.12,.23]:beam(benches,(a[0]+nx*o,a[1]+ny*o,.617),(c[0]+nx*o,c[1]+ny*o,.617),.092,.066,wood)
            for z in [.79,.94]:
                beam(benches,(a[0]+nx*.30,a[1]+ny*.3,z),(c[0]+nx*.30,c[1]+ny*.3,z),.08,.111,wood)
    floor.build('Terrace | 红褐廊道及亭台铺地','pavilion');frame.build('Structure | 方柱、柱础、檩梁与檐板','pavilion')
    tiles.build('Pavilion | 三开间蓝灰曲面瓦顶','pavilion');details.build('Roof details | 筒瓦、脊瓦、翘角及逐根廊架格栅','pavilion')
    rail.build('Rails | 两翼弧形木扶手与竖杆','pavilion');benches.build('Benches | 廊下原木条椅','pavilion')
