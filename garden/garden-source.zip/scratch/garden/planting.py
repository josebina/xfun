from common import *
leafA=mat('L01  阔叶枝梢 A','#557136',.92,'leaf_a.png',clip=True)
leafB=mat('L02  阔叶枝梢 B','#597840',.93,'leaf_b.png',clip=True)
leafG=mat('L03  黄绿阔叶梢','#9aaf36',.89,'leaf_gold.png',clip=True)
needle=mat('L04  针叶枝梢','#405e49',.93,'cedar.png',clip=True)
coregreen=mat('L11  深绿冠层','#4b623d',.95,'crown.jpg',.63)
coregold=mat('L12  黄绿冠层','#95ac3f',.93,'crown_gold.jpg',.62)
corecedar=mat('L13  针叶冠层','#3a5445',.94,'crown_cedar.jpg',.67)
def spray(b,p,v,wide,m,spin,r):
    # A gently folded two-sided sprig, with its normals following the branch.
    a=V(p);v=V(v);length=v.length
    if length<.001:return
    direction=v.normalized();cross=direction.cross(V((0,0,1)))
    if cross.length<.01:cross=direction.cross(V((0,1,0)))
    cross.normalize();n=direction.cross(cross);side=cross*cos(spin)+n*sin(spin)
    normal=direction.cross(side);offset=normal*length*r.uniform(.045,.15)
    rows=[]
    for t,fac in [(0,.77),(.52,1.),(1,.72)]:
        mid=a+v*t+offset*sin(t*pi)
        rows.append(b.points([mid-side*wide*.52*fac,mid+normal*wide*.07,mid+side*wide*.52*fac]))
    for i in range(2):
        for j in range(2):
            u1=j*.5;u2=u1+.5;v1=[0,.52][i];v2=[.52,1][i]
            b.face([rows[i][j],rows[i][j+1],rows[i+1][j+1],rows[i+1][j]],m,True,[(u1,v1),(u2,v1),(u2,v2),(u1,v2)])
def clump(b,p,rad,m,r):
    # Irregular core mostly screened by leaf tips, avoiding clear through-crowns.
    x,y,z=p;rx,ry,rz=rad;n=10;rows=[];offset=r.random()*pi
    for i in range(1,6):
        ph=-pi/2+pi*i/6;parts=[]
        for j in range(n):
            t=offset+2*pi*j/n+r.uniform(-.09,.09);s=r.uniform(.76,1.13)
            parts.append((x+rx*s*cos(t)*cos(ph),y+ry*s*sin(t)*cos(ph),z+rz*sin(ph)+rz*r.uniform(-.09,.09)))
        rows.append(b.points(parts))
    lo,hi=b.points([(x,y,z-.88*rz),(x,y,z+rz)])
    for j in range(n):
        k=(j+1)%n;b.face([lo,rows[0][k],rows[0][j]],m,True);b.face([hi,rows[-1][j],rows[-1][k]],m,True)
    for l,u in zip(rows,rows[1:]):
        for j in range(n):k=(j+1)%n;b.face([l[j],l[k],u[k],u[j]],m,True)
def broadleaf(variant,gold=False):
    r=random.Random('broad'+str(variant));b=Mesh()
    wf=[1.,.87,1.09,1.02][variant%4];top=7.68
    leanx=r.uniform(-.33,.35); leany=r.uniform(-.22,.30)
    def trunk(z):return V((leanx*(z/top)**1.45,leany*z/top,z))
    pipe(b,[trunk(z) for z in [0,.35,1.2,2.65,4.1,5.9,7.20]],[.19,.145,.132,.115,.09,.055,.012],barks[variant%4],10)
    pipe(b,[trunk(z) for z in [.01,.42,1.0]],[.193,.145,.138],wash,10)
    lobes=[]
    for i in range(34):
        frac=(i+r.uniform(.13,.86))/34
        ztip=2.91+frac*4.58
        reach=(.55+1.82*max(.01,sin(pi*(.08+.88*frac)))**.68)*wf*r.uniform(.80,1.16)
        theta=i*2.39996+r.uniform(-.34,.34)
        zstart=max(1.55,ztip-r.uniform(1.23,2.62))
        a=trunk(zstart);d=V((cos(theta),sin(theta),0))
        end=trunk(ztip)+d*reach;mid=a+d*.45*reach+V((0,0,(ztip-zstart)*.28))
        pipe(b,[a,mid,end],[.066*(1-.40*frac),.045,.012],r.choice(barks),6)
        for j in range(2 if i%4 else 3):
            yaw=theta+r.uniform(-.85,.85);dd=V((cos(yaw),sin(yaw),0))
            scale=r.uniform(.66,1.06) if j==0 else r.uniform(.46,.83)
            p=end+dd*r.uniform(-.29,.36)+V((0,0,r.uniform(-.20,.34)))
            start=mid.lerp(end,r.uniform(.33,.67));pipe(b,[start,p-V((0,0,.18)),p],[.030,.019,.008],barks[1],5)
            lobes.append((p,scale))
    lobes.extend([(trunk(z)+V((r.uniform(-.35,.35),r.uniform(-.35,.35),0)),r.uniform(.6,.86)) for z in [3.8,4.5,5.6,6.3,6.9,7.4]])
    for p,scale in lobes:
        rx=scale*r.uniform(.83,1.16);ry=scale*r.uniform(.77,1.13);rz=scale*r.uniform(.79,1.13)
        clump(b,p,(rx*.77,ry*.77,rz*.84),coregold if gold else coregreen,r)
        for j in range(25 if gold else 28):
            a=r.random()*2*pi;k=r.uniform(-.83,1);kxy=sqrt(1-k*k)
            n=V((cos(a)*kxy,sin(a)*kxy,k))
            pos=p+V((rx*n.x,ry*n.y,rz*n.z))*.56
            v=n*r.uniform(.64,.98)*scale+V((r.uniform(-.10,.10),r.uniform(-.10,.10),r.uniform(-.07,.15)))
            spray(b,pos,v,r.uniform(.54,.89)*scale,leafG if gold else r.choice([leafA,leafB]),r.uniform(-1.55,1.55),r)
    return b.build('Tree prototype '+str(variant),'plants')
def conifer():
    r=random.Random(9934);b=Mesh();h=12.35
    pipe(b,[(0,0,0),(.04,-.02,1.4),(-.05,.07,5.2),(.11,.10,9.2),(.13,.1,h)],[.24,.193,.145,.070,.009],barks[3],10)
    for i in range(17):
        t=i/16;z=1.61+t*(h-1.82);radius=3.05*(1-t)**.71+.12
        count=13 if t<.58 else 10
        for j in range(count):
            ang=(j+r.uniform(-.19,.19))*2*pi/count+i*.56
            d=V((cos(ang),sin(ang),0));side=V((-sin(ang),cos(ang),0))
            L=radius*r.uniform(.74,1.12)
            base=V((.09*t,.09*t,z+r.uniform(-.17,.17)))
            mid=base+d*L*.68+V((0,0,-.39*L/3))
            tip=base+d*L+V((0,0,-.22*L/3+r.uniform(-.12,.19)))
            pipe(b,[base,mid,tip],[.047*(1-.6*t),.025,.009],barks[3],5)
            for k in range(7):
                frac=.14+.77*k/6;pos=base.lerp(tip,frac);pos.z-=.12*sin(frac*pi)
                width=(1-frac*.74)*min(.70,.36*L)
                for sd in [-1,1]:
                    spr=d*(.32+.21*frac)*min(1,L)+side*width*sd+V((0,0,-r.uniform(.06,.32)*min(1,L)))
                    spray(b,pos,spr,r.uniform(.37,.68)*min(1.3,.56+L*.35),needle,r.uniform(-.55,.55),r)
            if t<.9:
                # Interior foliage pads are tapered and broken by gaps between boughs.
                q=base+d*L*.48
                clump(b,q,(min(.75,L*.43),min(.75,L*.43),.24+.15*(1-t)),corecedar,r)
    return b.build('Cedar prototype','plants')
def shrub(kind):
    r=random.Random('bush'+str(kind));b=Mesh()
    col=['#5c733d','#756249','#758649','#647846','#8a543c','#778735']
    m=mat('L2%d  灌丛叶色'%kind,col[kind],.91)
    accents=[mat('L3%d-%d  灌丛嫩叶'%(kind,i),s,.92) for i,s in enumerate([col[kind],['#829353','#917153','#91a658','#748750','#a66e49','#93a646'][kind]])]
    for j in range(8):
        a=j*2.4;rad=.31 if j else 0
        p=V((rad*cos(a),rad*sin(a),r.uniform(.25,.54)))
        sx=r.uniform(.34,.54);clump(b,p,(sx,sx*.88,sx*.65),m,r)
        for k in range(47):
            theta=r.random()*2*pi;h=r.uniform(-.45,1);q=sqrt(1-h*h)
            n=V((cos(theta)*q,sin(theta)*q,h));c=p+V((sx*n.x,.88*sx*n.y,.65*sx*n.z))
            e=V((-sin(theta),cos(theta),0))*r.uniform(.031,.052)
            tip=c+n*r.uniform(.065,.102)+V((0,0,.026))
            b.poly([c-e,tip+V((0,0,.007)),c+e,c-n*.033],r.choice(accents),True)
    return b.build('Shrub prototype '+str(kind),'plants')
def residual_saplings():
    b=Mesh();cord=mat('T04  树木绑缚带','#5a5d48',.95);stake=mat('T03  支撑木杆','#82785b',.88)
    for i,(u,v,h) in enumerate([(520,561,6.1),(580,549,7.4),(620,541,6.5),(681,541,6.9),(712,553,6.6)]):
        x,y=xy(u,v,2.0);z=turfz(x,y);tilt=[-.18,.12,-1.30,1.18,-.04][i]
        p=V((x,y,z));m=barks[i%4]
        pipe(b,[p,p+V((tilt*.23,.01,h*.28)),p+V((tilt*.70,.10,h*.68)),p+V((tilt,.16,h))],[.079,.063,.037,.013],m,7)
        pipe(b,[p,p+V((tilt*.20,0,.59))],[.082,.070],wash,7)
        for j in range(7):
            q=p+V((tilt*(.50+j*.06),.08,h*(.51+j*.073)))
            d=V((rng.uniform(-.67,.67),rng.uniform(-.53,.50),rng.uniform(.26,1.10)))
            pipe(b,[q,q+d*.55,q+d],[.023,.014,.0045],m,5)
        if i in [0,1,4]:
            q=p+V((tilt*.36,0,2.24))
            for ang in [.35,2.5,4.48]:
                xx=x+cos(ang)*1.25;yy=y+sin(ang)*1.25
                rod(b,(xx,yy,turfz(xx,yy)),q,.037,stake,7)
            pipe(b,[q-V((0,0,.055)),q+V((0,0,.055))],.080,cord,8)
    b.build('Saplings | 后缘幼树、树干涂白与三角撑','plants')
def create_plants():
    variants=[broadleaf(i) for i in range(3)]
    gold=broadleaf(3,True);cedar=conifer()
    # Scales follow the image-derived projected height for each visible trunk.
    front=[(-17.9,-4.5,7.35,1.03,0),(-16.8,8.,10.0,1.04,1),(-28.3,-7.9,4.65,.79,1),(-28.,12.6,4.3,.78,0),(17.3,5.7,10.1,1.03,0),(17.8,-5.4,8.32,1.12,2),(17.35,-20.38,7.88,1.68,3)]
    for j,(x,y,h,w,mode) in enumerate(front):
        src=(variants+[gold])[mode];s=h/8.13
        place_shared(src,'Courtyard tree %02d | 庭园乔木'%j,'plants',x,y,.04,(s*w,s*w,s),rng.random()*2*pi)
    rear=[(-20.6,49.0,18.3,1.02),(-12.2,49.6,15.7,1.12),(-3.3,50.4,16.2,.97),(3.6,54.6,15.1,1.1),(18.5,51.2,17.3,1.08),(24.3,52.6,16.2,1.03),(-29.2,54.8,16.5,1.2)]
    for j,(x,y,h,w) in enumerate(rear):
        s=h/8.13;place_shared(variants[j%3],'Rear canopy %02d | 后排阔叶树'%j,'backtrees',x,y,0,(s*w,s*w,s),j*2.132)
    for j,(x,y,h,w) in enumerate([(10.05,45.2,15.05,1.19),(16.65,43.0,12.9,1.10),(25.45,30.25,13.35,1.04)]):
        s=h/12.35;place_shared(cedar,'Cedar %02d | 层生针叶乔木'%j,'backtrees',x,y,.01,(s*w,s*w,s),j*1.93)
    for j,(x,y,h) in enumerate([(-54,14,17.3),(-54,24,17.8),(-53,35,16.6),(-55,46,17.7),(-53,57,16.7),(-54,69,17.8),(-49,80,17.6)]):
        sc=h/8.13;place_shared(variants[j%3],f'West backdrop {j:02d} | 楼后树冠','backtrees',x,y,0,(sc*1.05,sc*1.05,sc),j*2.61)
    shrubs=[shrub(i) for i in range(6)]
    idx=0
    for sd in [-1,1]:
        for yy in [-18.5,-13.6,-8.4,-3.6,1.75,8.7,14.7,18.4]:
            for line in ([23.1,26.6,30.1] if sd<0 else [23.6,25.0,27.4]):
                if sd<0 and ((-18.7<yy<-14.0 or -5.6<yy<-.5 or 5.1<yy<8.8) and 22.0<line<28.2):continue
                if sd>0 and line>24.5 and -15<yy<-11:continue
                n=rng.choice([1,2,2,3,4]);size=rng.uniform(.56,1.06)
                varietal=rng.choice([0,0,1,2,3,4,5])
                for _ in range(n):
                    x=sd*line+rng.uniform(-.60,.60);y=yy+rng.uniform(-.67,.67)
                    s=size*rng.uniform(.65,1.2)
                    place_shared(shrubs[varietal],'Parterre bush %03d'%idx,'plants',x,y,.05,(s,s*rng.uniform(.81,1.10),s*rng.uniform(.64,1.09)),rng.random()*2*pi);idx+=1
    for sd in [-1,1]:
        for j in range(14):
            x=.24+sd*rng.uniform(1.78,5.70);y=rng.uniform(28.6,30.12);sz=rng.uniform(.51,.83)
            place_shared(shrubs[j%3],'Waterside shrubs %02d %s'%(j,sd),'plants',x,y,.30,(sz,sz,sz*.73),j)
    for ob in variants+[gold,cedar]+shrubs:bpy.data.objects.remove(ob,do_unlink=True)
    residual_saplings()
