import sys,bpy
from pathlib import Path
args=sys.argv[sys.argv.index('--')+1:];mode=args[0];n=int(args[1]);samples=int(args[2]);target=args[3]
s=bpy.context.scene
prefix={'match':'CAM 02','iso':'CAM 03','detail':'CAM 04','plan':'CAM 05','full':'CAM 01'}[mode]
s.camera=next(ob for ob in bpy.data.objects if ob.name.startswith(prefix))
if mode in ['iso','plan']:
    for c in bpy.data.collections:
        if c.name.startswith(('08 ','09 ')):c.hide_render=True
if mode=='iso':
    for c in bpy.data.collections:
        if c.name.startswith('09 '):c.hide_render=False
    for ob in bpy.data.objects:
        if ob.name.startswith('West backdrop'):ob.hide_render=True
if mode=='plan':
    s.camera.data.ortho_scale=85.0;s.camera.location.y=11.0
s.cycles.use_denoising=False
s.cycles.samples=samples;s.cycles.adaptive_threshold=.095 if samples>6 else .2
s.render.resolution_x=n;s.render.resolution_y=round(n*{'match':617/1280,'iso':.88,'detail':.54,'plan':1.0,'full':.75}[mode])
s.render.resolution_percentage=100;s.render.filepath=target
if mode=='iso':
    from mathutils import Vector
    import numpy as np
    cam=s.camera;inv=cam.matrix_world.inverted();pts=[]
    for ob in s.objects:
        if ob.type!='MESH' or ob.hide_render or any(c.hide_render for c in ob.users_collection):continue
        pts.extend([inv @ (ob.matrix_world @ Vector(co)) for co in ob.bound_box])
    q=np.asarray([v[:] for v in pts]);mn=q.min(0);mx=q.max(0)
    center=(mx+mn)*.5;cam.location+=cam.rotation_euler.to_quaternion() @ Vector((center[0],center[1],0))
    cam.data.ortho_scale=max(mx[0]-mn[0],(mx[1]-mn[1])/(s.render.resolution_y/s.render.resolution_x))*1.025

bpy.ops.render.render(write_still=True)
