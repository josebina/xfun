from PIL import Image,ImageDraw,ImageFont,ImageFilter
from pathlib import Path
import numpy as np,math
from calib import project,H,OX,OY
ROOT=Path(__file__).parent;OUT=Path('/workspace/花园重建')
def simple_denoise(image,n=2):
    # Local bilateral denoising at sub-pixel scale, retaining high-contrast geometry.
    a=np.array(image.convert('RGB'),dtype=np.float32)
    for _ in range(n):
        w=np.ones(a.shape[:2],np.float32)*2.4;val=a*2.4
        for dx,dy in [(0,1),(0,-1),(1,0),(-1,0),(1,1),(-1,1),(1,-1),(-1,-1)]:
            q=np.roll(a,(dx,dy),(0,1));diff=np.mean((a-q)**2,2)
            wt=np.exp(-diff/230)*(.75 if dx!=0 and dy!=0 else 1.0)
            val+=q*wt[:,:,None];w+=wt
        a=val/w[:,:,None]
    return Image.fromarray(np.uint8(np.clip(a,0,255)))
def prep_render(name):
    source=ROOT/(name+'-final.png')
    if not source.exists():source=ROOT/(name+'.png')
    im=simple_denoise(Image.open(source),2)
    im.save(ROOT/(name+'_render.jpg'),quality=95,subsampling=0)
    if name=='iso':im.save(OUT/'轴测总览.jpg',quality=95,subsampling=0)
    return im
def contour():
    im=Image.open(ROOT/'reference.jpg').convert('RGB')
    o=im.crop((363,521,938,870)).resize((1150,698),Image.Resampling.LANCZOS);d=ImageDraw.Draw(o)
    def zcrest(x,y):return 2.06+.08*math.sin(x*.32+y*.11)*math.cos(y*.33)-.19*math.exp(-((x-1.)**2/35+(y-1.8)**2/28))+.06*math.sin(.17*y-.30*x)
    for layer,rx,ry,colour in [('toe',13.32,14.79,'#f5c650'),('crest',11.95,11.9,'#97f8dc')]:
        line=[]
        for j,t in enumerate(np.linspace(0,2*math.pi,361)):
            xx,yy=rx*math.cos(t),ry*math.sin(t);a=.14
            x=-.14+xx*math.cos(a)-yy*math.sin(a);y=-1.07+xx*math.sin(a)+yy*math.cos(a)
            u,v=project(x+OX,y+OY,.04 if layer=='toe' else zcrest(x,y),H)
            line.append(((u-363)*2,(v-521)*2))
            if j>0 and (layer=='crest' or y<-1 or (j//5)%2==0):
                d.line(line[-2:],fill=colour,width=3 if layer=='toe' else 2)
    o.save(ROOT/'contour.jpg',quality=94)
def comparison():
    W=1550;left=58;right=W-left;imgw=right-left
    hh=round(imgw*617/1280);H2=144+2*hh+139
    canvas=Image.new('RGB',(W,H2),'#f5f4ec');d=ImageDraw.Draw(canvas)
    sans='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';bold='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc';serif='/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc'
    font=lambda path,n:ImageFont.truetype(path,n,index=2)
    d.text((left,24),'教学楼庭院',font=font(serif,52),fill='#263d31')
    d.text((right,59),'原机位对照',anchor='rm',font=font(sans,24),fill='#566959')
    d.line((left,106,right,106),fill='#b9c0ae',width=2)
    for i,(name,img) in enumerate([('原始照片 · 庭院裁切',Image.open(ROOT/'reference.jpg').crop((0,269,1280,886))),('三维模型 · 同机位渲染',Image.open(ROOT/'match_render.jpg'))]):
        y=145+i*(hh+60);d.text((left,y-31),name,font=font(bold,18),fill='#39513e')
        canvas.paste(img.convert('RGB').resize((imgw,hh),Image.Resampling.LANCZOS),(left,y))
    d.text((left,H2-43),'草坡坡脚约 26.6 × 29.6 米　　草坪上缘高出环道约 2 米',font=font(sans,19),fill='#425641')
    canvas.save(OUT/'原机位对照.jpg',quality=94,subsampling=0)
if __name__=='__main__':
    contour()
    for name in ['match','iso','detail']:
        if (ROOT/(name+'.png')).exists():prep_render(name)
    comparison()
