from playwright.sync_api import sync_playwright
from pathlib import Path
import os
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--disable-crashpad-for-testing','--disable-crash-reporter','--no-sandbox','--disable-dev-shm-usage','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    page=browser.new_page(viewport={'width':1170,'height':745},device_scale_factor=1,accept_downloads=True)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('console',lambda m: print(m.type,m.text[:280],flush=True) if m.type in ['warning','error'] else None)
    page.context.set_offline(True)
    page.set_content(Path('/workspace/花园重建/三维查看器.html').read_text(),wait_until='domcontentloaded',timeout=120000)
    page.wait_for_selector('body[data-ready=true]',timeout=100000)
    page.wait_for_timeout(1450)
    print('ready',page.locator('#status').is_visible(),page.evaluate('engine.info.render.triangles'),flush=True)
    page.screenshot(path='viewer-check.jpg',type='jpeg',quality=88,timeout=120000)
    page.get_by_role('button',name='原照叠合').click();assert page.locator('#mixpanel').is_visible()
    page.locator('#mix').fill('75');assert page.locator('#pct').inner_text()=='75%'
    page.get_by_role('button',name='轴测',exact=True).click();assert not page.locator('#mixpanel').is_visible()
    page.get_by_role('button',name='图层').click();assert not page.locator('input[data-g=buildings]').is_checked()
    page.locator('input[data-g=activity]').uncheck();assert page.evaluate("layers.get('activity').visible")==False
    page.get_by_role('button',name='平面',exact=True).click();assert page.evaluate('camera.isOrthographicCamera')==True
    page.get_by_role('button',name='亭廊近景').click();assert page.evaluate('camera.isPerspectiveCamera')==True
    page.get_by_role('button',name='原机位',exact=True).click()
    with page.expect_download(timeout=120000) as d:page.get_by_role('button',name='保存 GLB').click()
    assert d.value.suggested_filename=='庭院.glb'
    import hashlib
    assert hashlib.sha256(Path(d.value.path()).read_bytes()).digest()==hashlib.sha256(Path('/workspace/花园重建/庭院.glb').read_bytes()).digest()
    print('Browser checks completed',errors,flush=True);assert not errors
    browser.close()
