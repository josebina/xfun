import bpy,json
from pathlib import Path
s=bpy.context.scene
assert s.unit_settings.system=='METRIC' and abs(s.unit_settings.scale_length-1)<1e-8
ims=[i for i in bpy.data.images if i.source=='FILE' and i.users>0];assert all(i.packed_file for i in ims)
assert any(i.name.startswith('CAM 01') for i in s.objects)
assert any(i.name.startswith('CAM 05') for i in s.objects)
assert len([c for c in bpy.data.collections if c.name.startswith('07 ')])==1
print('Packed images',len(ims),'named groups',len(s.collection.children),'cameras',len([o for o in s.objects if o.type=='CAMERA']))
print('Native project verified')
